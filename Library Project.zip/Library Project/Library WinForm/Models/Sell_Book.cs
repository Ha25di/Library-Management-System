﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Sell_Book
    {
        public int Sale_Book_id { get; set; }

        public int BookId { get; set; }

        public int Customer_id_Sell { get; set; }

        public string E_username_Sell { get; set; }

        public DateTime saleDate { get; set; }
    }
}
