﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Book
    {
        public int Book_id { get; set; }
        public string Title { get; set; }

        public string Genre { get; set; }

        public string ISBN { get; set; }

        public DateTime Published_Date { get; set; }

        public decimal Rent_Price { get; set; }

        public decimal Sell_Price { get; set; }

        public int NumberOfCopies_Available { get; set; }

        public int Book_Author_id { get; set; }

        public int Book_Publisher_id { get; set; }
    }
}
