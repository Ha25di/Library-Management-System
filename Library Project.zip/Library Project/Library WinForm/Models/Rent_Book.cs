﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Rent_Book
    {
        public int Rent_Book_Id { get; set; }

        public int BookId { get; set; }

        public int Customer_id_Rent { get; set; }

        public string E_Username_Rent { get; set; }

        public DateTime Rent_Start_Date { get; set; }

        public DateTime Rent_End_Date { get; set; }

    }
}
