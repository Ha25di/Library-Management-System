﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Customer
    {
        public int Customer_id { get; set; }

        public string First_name { get; set; }
        public string Last_name { get; set; }

        public string Address { get; set; }

        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        public DateTime DOB { get; set; }

        public string Customer_Username { get; set; }
    }
}
