﻿using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess_Layer
{
    public class Book_DAL
    {
        public async Task AddBook(Book book)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    
                    string jsonCustomer = JsonConvert.SerializeObject(book);
                    StringContent content = new StringContent(jsonCustomer, Encoding.UTF8, "application/json");

                    
                    var response = await client.PostAsync("Book", content);

                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Book added successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Failed to add book.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
            }
        }



        public async Task<Book> getBookById(int id)
        {
            try
            {
                Book book = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync($"Book/id/{id}");
                    if (response.IsSuccessStatusCode)
                    {
                        book = await response.Content.ReadAsAsync<Book>();
                    }
                }
                return book;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }


        public async Task<Book> getBookByTitle(string title)
        {
            try
            {
                Book book = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync($"Book/title/{title}");
                    if (response.IsSuccessStatusCode)
                    {
                        book = await response.Content.ReadAsAsync<Book>();
                    }
                }
                return book;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }

        public async Task<IEnumerable<Book>> getBookByGenre(string genre)
        {
            try
            {
                IEnumerable<Book> books = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync($"Book/genre/{genre}");
                    if (response.IsSuccessStatusCode)
                    {
                        books = await response.Content.ReadAsAsync<IList<Book>>();
                    }
                }
                return books;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }


        public async Task<IEnumerable<Book>> getAllBooks()
        {
            try
            {
                IEnumerable<Book> books = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync("Book");
                    if (response.IsSuccessStatusCode)
                    {
                        books = await response.Content.ReadAsAsync<IList<Book>>();
                    }
                }
                return books;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }

        public async Task<bool> DeleteBookById(int id)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                   
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.DeleteAsync($"Book/{id}");
                    return response.IsSuccessStatusCode;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
             
                return false;
            }
        }

        public async Task<bool> UpdateNumOfCopies(int id, int NumOfCopies)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var data = new
                    {
                        Id = id,
                        nb= NumOfCopies
                    };

                    
                    var content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");

                    
                    

                    var response = await client.PutAsync($"Book/{id}/{NumOfCopies}", content);

                   Console.WriteLine("DAL: " + response.IsSuccessStatusCode);
                   return response.IsSuccessStatusCode;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");

                return false;
            }
        }


        public async Task<int> GetNbAvailableById(int Id)
        {
            try
            {
                int nb = -1;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync($"Book/NbAvailable/{Id}");
                    if (response.IsSuccessStatusCode)
                    {
                        nb = await response.Content.ReadAsAsync<int>();
                    }
                }
                return nb;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return -1;
            }
        }


        public async Task decreaseCopies(int id)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var data = new
                    {
                        Id = id,
                        
                    };

                    
                    var content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");

                    
                    

                    var response = await client.PutAsync($"Book/decreaseQty/{id}", content);

                    Console.WriteLine("DAL: " + response.IsSuccessStatusCode);
                    return;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");

                return;
            }
        }


        public async Task<decimal> GetRentPriceById(int Id)
        {
            try
            {
                decimal price = -1;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync($"Book/Rent_Price/{Id}");
                    if (response.IsSuccessStatusCode)
                    {
                        price = await response.Content.ReadAsAsync<decimal>();
                    }
                }
                return price;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return -1;
            }
        }

        public async Task<decimal> GetSellPriceById(int Id)
        {
            try
            {
                decimal price = -1;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync($"Book/Sell_Price/{Id}");
                    if (response.IsSuccessStatusCode)
                    {
                        price = await response.Content.ReadAsAsync<decimal>();
                    }
                }
                return price;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return -1;
            }
        }

        public async Task IncreaseCopiesAfterRent()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var data = new
                    {
                        

                    };

                   
                    var content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");

                    
                    

                    var response = await client.PutAsync($"Book/increaseAfterRent", content);

                    Console.WriteLine("DAL: " + response.IsSuccessStatusCode);
                    return;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");

                return;
            }
        }









    }
}
