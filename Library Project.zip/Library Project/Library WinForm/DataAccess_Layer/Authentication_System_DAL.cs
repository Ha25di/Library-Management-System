﻿using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess_Layer
{
    public class Authentication_System_DAL
    {
        public async Task<bool> CheckUsername(string username, string password)
        {

            try
            {
                Authentication_System e = new Authentication_System();
                e.Password = password;
                e.Username = username;

                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");
                    
                    string jsonCustomer = JsonConvert.SerializeObject(e);
                    StringContent content = new StringContent(jsonCustomer, Encoding.UTF8, "application/json");

                    
                    var response = await client.PostAsync("Authentication/checkUser", content);

                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("success");
                        
                        return true;
                    }
                    else
                    {
                        Console.WriteLine("Failure");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.GetType().FullName}");
                Console.WriteLine($"Message: {ex.Message}");
                Console.WriteLine($"Stack Trace:\n{ex.StackTrace}");
                return false;
            }

        }


        public async Task<IEnumerable<Authentication_System>> getAllUsernames()
        {
            try
            {
                IEnumerable<Authentication_System> emps = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync("Authentication");
                    if (response.IsSuccessStatusCode)
                    {
                        emps = await response.Content.ReadAsAsync<IList<Authentication_System>>();
                    }
                }
                return emps;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }
    }

}