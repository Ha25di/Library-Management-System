﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Models;
using System.Net;
using Newtonsoft.Json;

namespace DataAccess_Layer
{
    public class Customer_DAL
    {

        public async Task<IEnumerable<Customer>> getAllCustomers()
        {
            try
            {
                IEnumerable<Customer> customers = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync("Customer");
                    if (response.IsSuccessStatusCode)
                    {
                        customers = await response.Content.ReadAsAsync<IList<Customer>>();
                    }
                }
                return customers;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }

        public async Task AddCustomer(Customer customer)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    
                    string jsonCustomer = JsonConvert.SerializeObject(customer);
                    StringContent content = new StringContent(jsonCustomer, Encoding.UTF8, "application/json");
                    
                   
                    var response = await client.PostAsync("Customer", content);

                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Customer added successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Failed to add customer.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
            }

        }


        public async Task<Customer> getCustomerById(int id)
        {
            try
            {
                Customer customer = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync($"Customer/{id}");
                    if (response.IsSuccessStatusCode)
                    {
                        customer = await response.Content.ReadAsAsync<Customer>();
                    }
                }
                return customer;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }

        public async Task<bool> DeleteCustomerById(int id)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.DeleteAsync($"Customer/{id}");
                    return response.IsSuccessStatusCode;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return false;
            }
        }








    }
}




   