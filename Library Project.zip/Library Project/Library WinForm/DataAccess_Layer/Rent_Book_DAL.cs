﻿using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess_Layer
{
    public class Rent_Book_DAL
    {
        public async Task AddRentedBook(Rent_Book rentBook)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

            
                    string jsonCustomer = JsonConvert.SerializeObject(rentBook);
                    StringContent content = new StringContent(jsonCustomer, Encoding.UTF8, "application/json");

                   
                    var response = await client.PostAsync("Rent_Book", content);

                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Rented Book added successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Failed to add Rented Book.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
            }
        }


        public async Task<IEnumerable<Rent_Book>> getAllRentedBooks()
        {
            try
            {
                IEnumerable<Rent_Book> Rbooks = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync("Rent_Book");
                    if (response.IsSuccessStatusCode)
                    {
                        Rbooks = await response.Content.ReadAsAsync<IList<Rent_Book>>();
                    }
                }
                return Rbooks;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }




       public async Task<IEnumerable<Rent_Book>> getRentedBookByCustId(int cust_id)
        {
            try
            {
                IEnumerable<Rent_Book> Rbooks = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync($"Rent_Book/{cust_id}");
                    if (response.IsSuccessStatusCode)
                    {
                        Rbooks = await response.Content.ReadAsAsync<IList<Rent_Book>>();
                    }
                }
                return Rbooks;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }




    }
}
