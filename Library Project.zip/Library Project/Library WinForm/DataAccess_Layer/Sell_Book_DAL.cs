﻿using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess_Layer
{
    public class Sell_Book_DAL
    {
        public async Task AddSoldBook(Sell_Book sellBook)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");


                    string jsonCustomer = JsonConvert.SerializeObject(sellBook);
                    StringContent content = new StringContent(jsonCustomer, Encoding.UTF8, "application/json");


                    var response = await client.PostAsync("Sell_Book", content);

                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Sold Book added successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Failed to add Sold Book.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
            }
        }


        public async Task<IEnumerable<Sell_Book>> getAllSoldBooks()
        {
            try
            {
                IEnumerable<Sell_Book> sbooks = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync("Sell_Book");
                    if (response.IsSuccessStatusCode)
                    {
                        sbooks = await response.Content.ReadAsAsync<IList<Sell_Book>>();
                    }
                }
                return sbooks;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }

        public async Task<IEnumerable<Sell_Book>> getSoldBookByCustId(int cust_id)
        {
            try
            {
                IEnumerable<Sell_Book> sbooks = null;
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost:44356/Api/");

                    var response = await client.GetAsync($"Sell_Book/{cust_id}");
                    if (response.IsSuccessStatusCode)
                    {
                        sbooks = await response.Content.ReadAsAsync<IList<Sell_Book>>();
                    }
                }
                return sbooks;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }


    }
}
