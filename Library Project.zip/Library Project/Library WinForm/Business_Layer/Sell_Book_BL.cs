﻿using DataAccess_Layer;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer
{
    public class Sell_Book_BL
    {
        Sell_Book_DAL sb = new Sell_Book_DAL();

        public async Task AddSoldBook(Sell_Book soldBook)
        {
            await sb.AddSoldBook(soldBook);
        }

        public async Task<IEnumerable<Sell_Book>> getAllSoldBooks()
        {
            return await sb.getAllSoldBooks();
        }


        public async Task<IEnumerable<Sell_Book>> getSoldBookByCustId(int cust_id)
        {
            return await sb.getSoldBookByCustId(cust_id);
        }
    }
}
