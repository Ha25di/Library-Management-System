﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DataAccess_Layer;
using System.Data;

namespace Business_Layer
{
    public class Book_BL
    {
        Book_DAL book_dal = new Book_DAL();
        public async Task AddBook(Book book)
        {
            await book_dal.AddBook(book);
        }

        public async Task<Book> getBookById (int id)
        {
            return await book_dal.getBookById(id);
        }

        public async Task<Book> getBookByTitle(string title)
        {
            return await book_dal.getBookByTitle(title);
        }

       public async Task<IEnumerable<Book>> getBookByGenre(string genre)
        {
            return await book_dal.getBookByGenre(genre);
        }

        public async Task<IEnumerable<Book>> getAllBooks()
        {
            return await book_dal.getAllBooks();
        }


        public async Task<bool> DeleteBookById(int id)
        {
           
            return await book_dal.DeleteBookById(id);
        }

        public async Task<bool> UpdateNumOfCopies(int id, int NumOfCopies)
        {
          
            return await book_dal.UpdateNumOfCopies(id, NumOfCopies);
        }


        public async Task<int> GetNbAvailableById(int Id)
        {
            return await book_dal.GetNbAvailableById(Id);
        }

        public async Task decreaseCopies(int id)
        {
            await book_dal.decreaseCopies(id);
        }

        public async Task<decimal> GetRentPriceById(int Id)
        {
            return await book_dal.GetRentPriceById(Id);
        }

        public async Task<decimal> GetSellPriceById(int Id)
        {
            return await book_dal.GetSellPriceById(Id);
        }

        public async Task IncreaseCopiesAfterRent()
        {
             await book_dal.IncreaseCopiesAfterRent();
        }
    }
}
