﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DataAccess_Layer;


namespace Business_Layer
{
    public class Rent_Book_BL
    {
        Rent_Book_DAL rb = new Rent_Book_DAL();

        public async Task AddRentedBook(Rent_Book rentBook)
        {
            await rb.AddRentedBook(rentBook);
        }

        public async Task<IEnumerable<Rent_Book>> getAllRentedBooks()
        {
            return await rb.getAllRentedBooks();
        }


        public async Task<IEnumerable<Rent_Book>> getRentedBookByCustId(int cust_id)
        {
            return await rb.getRentedBookByCustId(cust_id);
        }

    }
}
