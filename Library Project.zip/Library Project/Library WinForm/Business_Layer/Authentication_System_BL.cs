﻿using DataAccess_Layer;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer
{
    public class Authentication_System_BL
    {
        public Authentication_System_DAL  dal = new Authentication_System_DAL();


        public async Task<bool> CheckUsername(string username, string password)
        {
            return await dal.CheckUsername(username, password);
        }

        public async Task<IEnumerable<Authentication_System>> getAllUsernames()
        {
            return await dal.getAllUsernames();
        }
    }


}
