﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DataAccess_Layer;
using System.Data;

namespace Business_Layer
{
    public class Customer_BL
    {
        Customer_DAL cust = new Customer_DAL();

        public async Task<IEnumerable<Customer>> getAllCustomers()
        {
            return await cust.getAllCustomers();
        }

        public async Task AddCustomer(Customer customer)
        {
            await cust.AddCustomer(customer);
        }

        public async Task<Customer> getCustomerById(int id)
        {
            return await cust.getCustomerById(id);
        }

        public async Task<bool> DeleteCustomerById(int id)
        {
            return await cust.DeleteCustomerById(id);
        }
    }
}
