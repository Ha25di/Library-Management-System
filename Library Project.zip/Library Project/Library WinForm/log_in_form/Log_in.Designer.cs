﻿namespace log_in_form
{
    partial class Log_in
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AddCustTableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Label = new System.Windows.Forms.Label();
            this.DateLabel = new System.Windows.Forms.Label();
            this.datelabel1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.password = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.LogInBtn = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.AddCustTableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // AddCustTableLayoutPanel1
            // 
            this.AddCustTableLayoutPanel1.BackColor = System.Drawing.Color.LightBlue;
            this.AddCustTableLayoutPanel1.ColumnCount = 4;
            this.AddCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.AddCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.AddCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.AddCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 295F));
            this.AddCustTableLayoutPanel1.Controls.Add(this.Label, 1, 0);
            this.AddCustTableLayoutPanel1.Controls.Add(this.DateLabel, 2, 0);
            this.AddCustTableLayoutPanel1.Controls.Add(this.datelabel1, 3, 0);
            this.AddCustTableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.AddCustTableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.AddCustTableLayoutPanel1.Name = "AddCustTableLayoutPanel1";
            this.AddCustTableLayoutPanel1.RowCount = 1;
            this.AddCustTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.AddCustTableLayoutPanel1.Size = new System.Drawing.Size(1022, 75);
            this.AddCustTableLayoutPanel1.TabIndex = 1;
            // 
            // Label
            // 
            this.Label.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label.AutoSize = true;
            this.Label.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.Label.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Label.Location = new System.Drawing.Point(290, 26);
            this.Label.Name = "Label";
            this.Label.Size = new System.Drawing.Size(201, 23);
            this.Label.TabIndex = 0;
            this.Label.Text = "Log in to your Account";
            // 
            // DateLabel
            // 
            this.DateLabel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.DateLabel.AutoSize = true;
            this.DateLabel.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.DateLabel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.DateLabel.Location = new System.Drawing.Point(665, 26);
            this.DateLabel.Name = "DateLabel";
            this.DateLabel.Size = new System.Drawing.Size(58, 23);
            this.DateLabel.TabIndex = 1;
            this.DateLabel.Text = "Date:";
            this.DateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // datelabel1
            // 
            this.datelabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.datelabel1.AutoSize = true;
            this.datelabel1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.datelabel1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.datelabel1.Location = new System.Drawing.Point(729, 26);
            this.datelabel1.Name = "datelabel1";
            this.datelabel1.Size = new System.Drawing.Size(47, 23);
            this.datelabel1.TabIndex = 3;
            this.datelabel1.Text = "date";
            this.datelabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel25.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel25.ColumnCount = 3;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.92857F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.08595F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.98548F));
            this.tableLayoutPanel25.Controls.Add(this.password, 1, 1);
            this.tableLayoutPanel25.Controls.Add(this.label49, 0, 1);
            this.tableLayoutPanel25.Controls.Add(this.username, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.label50, 0, 0);
            this.tableLayoutPanel25.Location = new System.Drawing.Point(13, 143);
            this.tableLayoutPanel25.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.Padding = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.tableLayoutPanel25.RowCount = 2;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(996, 241);
            this.tableLayoutPanel25.TabIndex = 3;
            // 
            // password
            // 
            this.password.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.password.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.password.Location = new System.Drawing.Point(209, 167);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(231, 26);
            this.password.TabIndex = 10;
            this.password.UseSystemPasswordChar = true;
            this.password.Validating += new System.ComponentModel.CancelEventHandler(this.password_Validating);
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label49.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label49.Location = new System.Drawing.Point(106, 169);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(97, 23);
            this.label49.TabIndex = 0;
            this.label49.Text = "Password:";
            // 
            // username
            // 
            this.username.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.username.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.username.Location = new System.Drawing.Point(209, 47);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(231, 26);
            this.username.TabIndex = 8;
            this.username.Validating += new System.ComponentModel.CancelEventHandler(this.username_Validating);
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Transparent;
            this.label50.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label50.Location = new System.Drawing.Point(101, 48);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(102, 23);
            this.label50.TabIndex = 1;
            this.label50.Text = "Username:";
            // 
            // LogInBtn
            // 
            this.LogInBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LogInBtn.BackColor = System.Drawing.Color.LightBlue;
            this.LogInBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogInBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LogInBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.LogInBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LogInBtn.Location = new System.Drawing.Point(209, 3);
            this.LogInBtn.Name = "LogInBtn";
            this.LogInBtn.Size = new System.Drawing.Size(185, 38);
            this.LogInBtn.TabIndex = 11;
            this.LogInBtn.Text = "Log in";
            this.LogInBtn.UseVisualStyleBackColor = false;
            this.LogInBtn.Click += new System.EventHandler(this.LogInBtn_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.92857F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.08595F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.98548F));
            this.tableLayoutPanel1.Controls.Add(this.LogInBtn, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(13, 390);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(996, 89);
            this.tableLayoutPanel1.TabIndex = 12;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Log_in
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 526);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.tableLayoutPanel25);
            this.Controls.Add(this.AddCustTableLayoutPanel1);
            this.Name = "Log_in";
            this.Text = "Log in";
            this.AddCustTableLayoutPanel1.ResumeLayout(false);
            this.AddCustTableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel25.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel AddCustTableLayoutPanel1;
        private System.Windows.Forms.Label Label;
        private System.Windows.Forms.Label DateLabel;
        private System.Windows.Forms.Label datelabel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button LogInBtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

