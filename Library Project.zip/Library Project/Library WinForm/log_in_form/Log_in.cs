﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Models;
using System.Security.Cryptography;
using Business_Layer;
using LibraryWinForm;

namespace log_in_form
{
    public partial class Log_in : Form
    {

        public Log_in()
        {
            InitializeComponent();
            datelabel1.Text = DateTime.Now.ToString("dd-MM-yyyy");
        }

        
        private void username_Validating(object sender, CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = username.Text.Trim();

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(username, "Please enter the Librarian Username.");
                e.Cancel = true;
                return;
            }

            if (inputText.Length > 50)
            {
                errorProvider1.SetError(username, "Username should not exceed 50 characters.");
                e.Cancel = true;
                return;
            }
        }

        private void password_Validating(object sender, CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = password.Text.Trim();

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(password, "Please enter the password.");
                e.Cancel = true;
                return;
            }

          /*  if (inputText.Length > 16 || inputText.Length < 8)
            {
                errorProvider1.SetError(password, "password should be between 8 and 16 characters.");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(inputText, @"^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&+=!])(?!.*\s).{8,16}$"))
            {
                errorProvider1.SetError(password, "The password must be between 8 and 16 characters long " +
                    "with at least one uppercase letter, " +
                    "one lowercase letter, one digit, one special character, and no whitespace characters.");
                e.Cancel = true;
                return;
            }*/

            }

        private async void LogInBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(username.Text) && !string.IsNullOrEmpty(password.Text)){

                Authentication_System_BL emp= new Authentication_System_BL();
                Task<bool> task = emp.CheckUsername(username.Text, password.Text);
                bool emps = await task;
                if (emps == true)
                {
                    Form1 Check = new Form1();
                    Check.Show();
                    Hide();
                    //MessageBox.Show("Data retrieved successfully!");
                }
                else
                {
                    errorProvider1.SetError(LogInBtn, "Incorrect Username or Password.");
                    return;
                    
                }
            }

            else
            {
                errorProvider1.SetError(LogInBtn, "Please enter all fieldls.");
                return;
            }
        }
    }
}
