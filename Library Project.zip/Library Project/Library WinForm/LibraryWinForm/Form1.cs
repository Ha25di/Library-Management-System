﻿using System.Windows.Forms;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System;
using Business_Layer;
using Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.Net;

namespace LibraryWinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dateLabel4.Text = DateTime.Now.ToString("dd-MM-yyyy");
            datelabel2.Text = DateTime.Now.ToString("dd-MM-yyyy");
            dateLabel6.Text = DateTime.Now.ToString("dd-MM-yyyy");
            dateLabel7.Text = DateTime.Now.ToString("dd-MM-yyyy");
            dateLabel8.Text = DateTime.Now.ToString("dd-MM-yyyy");
            dateLabel9.Text = DateTime.Now.ToString("dd-MM-yyyy");
            dateLabel10.Text = DateTime.Now.ToString("dd-MM-yyyy");
            dateLabel11.Text = DateTime.Now.ToString("dd-MM-yyyy");
            dateLabel12.Text = DateTime.Now.ToString("dd-MM-yyyy");
            dateLabel13.Text = DateTime.Now.ToString("dd-MM-yyyy");
            dateLabel14.Text = DateTime.Now.ToString("dd-MM-yyyy");

        }

        private void Form1_Load(object sender, System.EventArgs e)
        {

        }



        private async void AddCustBtn_Click(object sender, System.EventArgs e)
        {
            if (!string.IsNullOrEmpty(First_Name.Text) &&
                !string.IsNullOrEmpty(Last_Name.Text) && !string.IsNullOrEmpty(Address.Text) &&
                !string.IsNullOrEmpty(Email.Text) && !string.IsNullOrEmpty(DOB.Text) &&
                !string.IsNullOrEmpty(Customer_Username.Text) && !string.IsNullOrEmpty(PhoneNumber.Text))
            {

                Customer customer = new Customer();


                customer.Last_name = Last_Name.Text;
                customer.First_name = First_Name.Text;
                customer.Address = Address.Text;
                customer.Email = Email.Text;
                customer.PhoneNumber = PhoneNumber.Text;
                customer.Customer_Username = Customer_Username.Text;

                if (DateTime.TryParse(DOB.Text, out DateTime dob))
                {
                    customer.DOB = dob;
                   
                }
                Customer_BL cust = new Customer_BL();
                await cust.AddCustomer(customer);
                


            }

            else
            {
                errorProvider1.SetError(AddCustBtn, "Please enter all fieldls.");
                return;
            }

        }

       /* private void Customer_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Customer_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Customer_id, "Please enter a customer id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int customerId))
            {
                errorProvider1.SetError(Customer_id, "Please enter a valid integer for the customer ID.");
                e.Cancel = true;
                return;
            }

            if (customerId < 1 || customerId > 1000)
            {
                errorProvider1.SetError(Customer_id, "Please enter an integer between 1 and 1000 for the customer ID.");
                e.Cancel = true;
            }

        }*/

        private void First_Name_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string firstName = First_Name.Text.Trim();


            if (string.IsNullOrEmpty(firstName))
            {
                errorProvider1.SetError(First_Name, "Please enter a first name.");
                e.Cancel = true;
                return;
            }

            if (firstName.Length > 20)
            {
                errorProvider1.SetError(First_Name, "First name should not exceed 20 characters.");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(firstName, @"^[a-zA-Z]+( [a-zA-Z]+)*$"))
            {
                errorProvider1.SetError(First_Name, "First name can only contain letters and single spaces.");
                e.Cancel = true;
                return;
            }

        }

        private void Last_Name_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string lastName = Last_Name.Text.Trim();


            if (string.IsNullOrEmpty(lastName))
            {
                errorProvider1.SetError(Last_Name, "Please enter a last name.");
                e.Cancel = true;
                return;
            }

            if (lastName.Length > 20)
            {
                errorProvider1.SetError(Last_Name, "Last name should not exceed 20 characters.");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(lastName, @"^[a-zA-Z]+( [a-zA-Z]+)*$"))
            {
                errorProvider1.SetError(Last_Name, "Last name can only contain letters and single spaces.");
                e.Cancel = true;
                return;
            }

        }

        private void Email_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string email = Email.Text.Trim();

            if (string.IsNullOrEmpty(email))
            {

                errorProvider1.SetError(Email, "Please enter an email address.");
                e.Cancel = true;
                return;
            }

            if (email.Length > 20)
            {
                errorProvider1.SetError(Email, "Email should not exceed 30 characters.");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(email, @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"))
            {
                errorProvider1.SetError(Email, "Please enter a valid email address.");
                e.Cancel = true;
                return;
            }

        }

        private void Address_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string address = Address.Text.Trim();

            if (string.IsNullOrEmpty(address))
            {

                errorProvider1.SetError(Address, "Please enter an address.");
                e.Cancel = true;
                return;
            }

            if (address.Length > 50)
            {
                errorProvider1.SetError(Address, "Address should not exceed 50 characters.");
                e.Cancel = true;
                return;
            }

        }

        private void DOB_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string dob = DOB.Text.Trim();

            if (string.IsNullOrEmpty(dob))
            {
                errorProvider1.SetError(DOB, "Please enter a date of birth (mm-dd-yyyy).");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(dob, @"^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])-(19[2-9][0-9]|20[0-1][0-9]|202[0-3])$"))
            {
                errorProvider1.SetError(DOB, "Please enter a valid date of birth in the format mm-dd-yyyy.");
                e.Cancel = true;
                return;
            }

        }

        private void Customer_Username_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string usr = Customer_Username.Text.Trim();

            if (string.IsNullOrEmpty(usr))
            {

                errorProvider1.SetError(Customer_Username, "Please enter a Username.");
                e.Cancel = true;
                return;
            }

            if (usr.Length > 50)
            {
                errorProvider1.SetError(Customer_Username, "Username should not exceed 50 characters.");
                e.Cancel = true;
                return;
            }

        }

        private void PhoneNumber_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string phoneNumber = PhoneNumber.Text.Trim();

            if (string.IsNullOrEmpty(phoneNumber))
            {
                errorProvider1.SetError(PhoneNumber, "Please enter a phone number in the format +961 70654321");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(phoneNumber, @"^\+\d{3}\s\d{8}$"))
            {
                errorProvider1.SetError(PhoneNumber, "Please enter a valid phone number in the format +961 70654321");
                e.Cancel = true;
                return;
            }
        }

        private void get_Customer_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = get_Customer_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(get_Customer_id, "Please enter a customer id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int customerId))
            {
                errorProvider1.SetError(get_Customer_id, "Please enter a valid integer for the customer ID.");
                e.Cancel = true;
                return;
            }

            if (customerId < 1 || customerId > 1000)
            {
                errorProvider1.SetError(get_Customer_id, "Please enter an integer between 1 and 1000 for the customer ID.");
                e.Cancel = true;
            }
        }

        private async void submitCustId_Click(object sender, System.EventArgs e)
        {
            if (!string.IsNullOrEmpty(get_Customer_id.Text))
            {
                //MessageBox.Show("hi");
                Customer_BL customer = new Customer_BL();
                if (int.TryParse(get_Customer_id.Text, out int customerId))
                {
                    Task<Customer> task = customer.getCustomerById(customerId);
                    Customer cust = await task;
                    if (cust != null)
                    {
                        // MessageBox.Show("Data retrieved successfully!");
                        dataGridView1.DataSource = new List<Customer> { cust };
                    }
                }

            }

            else
            {
                errorProvider1.SetError(submitCustId, "Please enter the id field.");
                return;
            }
        }

        private async void ViewAllBtn_Click(object sender, EventArgs e)
        {
            Customer_BL cust = new Customer_BL();
            Task<IEnumerable<Customer>> task = cust.getAllCustomers();
            IEnumerable<Customer> customers = await task;
            if (customers != null)
            {
                //MessageBox.Show("Data retrieved successfully!");
                dataGridView2.DataSource = customers.ToList();
            }
            else
            {
                MessageBox.Show("Error occurred while retrieving data.");
            }

        }

        private void custId_delete_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = custId_delete.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(custId_delete, "Please enter a customer id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int customerId))
            {
                errorProvider1.SetError(custId_delete, "Please enter a valid integer for the customer ID.");
                e.Cancel = true;
                return;
            }

            if (customerId < 1 || customerId > 1000)
            {
                errorProvider1.SetError(custId_delete, "Please enter an integer between 1 and 1000 for the customer ID.");
                e.Cancel = true;
            }
        }

        private async void submitBtnDlt_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(custId_delete.Text))
            {
                Customer_BL customer = new Customer_BL();

                if (int.TryParse(custId_delete.Text, out int customerId))
                {
                    bool deletionSuccessful = await customer.DeleteCustomerById(customerId);
                    if (deletionSuccessful)
                    {
                        messagelbl.Text = "Deleted Successfully !";
                    }
                    else
                    {
                        messagelbl.Text = "An error occured!";
                        Console.WriteLine("Failed to delete customer.");
                    }

                }

            }

            else
            {
                errorProvider1.SetError(submitBtnDlt, "Please enter the id field.");
                return;
            }

        }

        // This section is for add Book functionalites
        /*private void Book_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Book_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Book_id, "Please enter a book id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int bookId))
            {
                errorProvider1.SetError(Book_id, "Please enter a valid integer for the Book ID.");
                e.Cancel = true;
                return;
            }

            if (bookId < 1 || bookId > 1000)
            {
                errorProvider1.SetError(Book_id, "Please enter an integer between 1 and 1000 for the book ID.");
                e.Cancel = true;
            }

        }*/

        private void ISBN_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = ISBN.Text.Trim();

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(ISBN, "Please enter the book ISBN.");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(inputText, @"^(?=(?:\D*\d){10}(?:(?:\D*\d){3})?$)[\d-]+$"))
            {
                errorProvider1.SetError(ISBN, "Please enter a valid ISBN");
                e.Cancel = true;
                return;
            }

            if (inputText.Length > 20)
            {
                errorProvider1.SetError(ISBN, "ISBN should not exceed 20 characters.");
                e.Cancel = true;
                return;
            }
        }

        private void Title_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Title.Text.Trim();

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Title, "Please enter the book's title.");
                e.Cancel = true;
                return;
            }

            if (inputText.Length > 100)
            {
                errorProvider1.SetError(Title, "Title should not exceed 100 characters.");
                e.Cancel = true;
                return;
            }

        }

        private void Genre_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Genre.Text.Trim();

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Genre, "Please enter the book's genre.");
                e.Cancel = true;
                return;
            }

            if (inputText.Length > 50)
            {
                errorProvider1.SetError(Genre, "Genre should not exceed 50 characters.");
                e.Cancel = true;
                return;
            }

        }

        private void Published_Date_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string date = Published_Date.Text.Trim();

            if (string.IsNullOrEmpty(date))
            {
                errorProvider1.SetError(Published_Date, "Please enter the book's publishing date in the format (mm-dd-yyyy).");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(date, @"^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])-(16[0-9]{2}|17[0-9]{2}|18[0-9]{2}|19[0-9]{2}|20[0-2][0-9]|202[0-3])$"))
            {
                errorProvider1.SetError(Published_Date, "Please enter a valid publishing date between 1600 and 2023 in the format mm-dd-yyyy.");
                e.Cancel = true;
                return;
            }
        }

        private void Rent_Price_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Rent_Price.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Rent_Price, "Please enter a rent price for the book.");
                e.Cancel = true;
                return;
            }

            if (!decimal.TryParse(inputText, out decimal rp))
            {
                errorProvider1.SetError(Rent_Price, "Please enter a valid decimal number for the book rent price in $.");
                e.Cancel = true;
                return;
            }

            if (rp < 1 || rp > 100)
            {
                errorProvider1.SetError(Rent_Price, "Please enter a valid decimal number for the book rent price in $ between 1$ and 100$.");
                e.Cancel = true;
            }
        }

        private void Sell_Price_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Sell_Price.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Sell_Price, "Please enter a sell price for the book.");
                e.Cancel = true;
                return;
            }

            if (!decimal.TryParse(inputText, out decimal sp))
            {
                errorProvider1.SetError(Sell_Price, "Please enter a valid decimal number for the book sell price in $.");
                e.Cancel = true;
                return;
            }

            if (sp < 1 || sp > 1000)
            {
                errorProvider1.SetError(Sell_Price, "Please enter a valid decimal number for the book sell price in $ between 1$ and 1000$.");
                e.Cancel = true;
            }
        }

        private void NumberOfCopies_Available_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = NumberOfCopies_Available.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(NumberOfCopies_Available, "Please enter the number of copies available for this book.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int nb))
            {
                errorProvider1.SetError(NumberOfCopies_Available, "Please enter a valid integer for the number of copies available.");
                e.Cancel = true;
                return;
            }

            if (nb < 1)
            {
                errorProvider1.SetError(NumberOfCopies_Available, "Please enter an integer larger than 1 for the number of copies available.");
                e.Cancel = true;
            }

        }

        private void author_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = author_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(author_id, "Please enter this book's author id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int id))
            {
                errorProvider1.SetError(author_id, "Please enter a valid integer for the author id.");
                e.Cancel = true;
                return;
            }

            if (id < 1)
            {
                errorProvider1.SetError(author_id, "Please enter an integer larger than 1 for the author id.");
                e.Cancel = true;
            }

        }

        private void publisher_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = publisher_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(publisher_id, "Please enter this book's publisher id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int id))
            {
                errorProvider1.SetError(publisher_id, "Please enter a valid integer for the publisher id.");
                e.Cancel = true;
                return;
            }

            if (id < 1)
            {
                errorProvider1.SetError(publisher_id, "Please enter an integer larger than 1 for the publisher id.");
                e.Cancel = true;
            }


        }

        private async void addBookBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(ISBN.Text) &&
                !string.IsNullOrEmpty(Title.Text) && !string.IsNullOrEmpty(Genre.Text) &&
                !string.IsNullOrEmpty(Published_Date.Text) && !string.IsNullOrEmpty(author_id.Text) &&
                !string.IsNullOrEmpty(publisher_id.Text) && !string.IsNullOrEmpty(Rent_Price.Text)
                && !string.IsNullOrEmpty(Sell_Price.Text) && !string.IsNullOrEmpty(NumberOfCopies_Available.Text))
            {

                Book book = new Book();
               
                if (decimal.TryParse(Rent_Price.Text, out decimal rp))
                {
                    book.Rent_Price = rp;
                }
                if (decimal.TryParse(Sell_Price.Text, out decimal sp))
                {
                    book.Sell_Price = sp;
                }
                if (int.TryParse(author_id.Text, out int id1))
                {
                    book.Book_Author_id = id1;
                }

                if (int.TryParse(publisher_id.Text, out int id2))
                {
                    book.Book_Publisher_id = id2;
                }

                if (int.TryParse(NumberOfCopies_Available.Text, out int nb))
                {
                    book.NumberOfCopies_Available = nb;
                }
                book.ISBN = ISBN.Text;
                book.Title = Title.Text;
                book.Genre = Genre.Text;
                if (DateTime.TryParse(Published_Date.Text, out DateTime d))
                {
                    book.Published_Date = d;
                }

                Book_BL Book = new Book_BL();
                await Book.AddBook(book);

            }

            else
            {
                errorProvider1.SetError(addBookBtn, "Please enter all fieldls.");
                return;
            }
        }

        // This section is for getting a book by id, genre, title
        private void getBook_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = getBook_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(getBook_id, "Please enter a book id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int bookId))
            {
                errorProvider1.SetError(getBook_id, "Please enter a valid integer for the Book ID.");
                e.Cancel = true;
                return;
            }

            if (bookId < 1 || bookId > 1000)
            {
                errorProvider1.SetError(getBook_id, "Please enter an integer between 1 and 1000 for the book ID.");
                e.Cancel = true;
            }

        }

        private async void getBookIdBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(getBook_id.Text))
            {
                //MessageBox.Show("hi");
               Book_BL book = new Book_BL();
                if (int.TryParse(getBook_id.Text, out int bookId))
                {
                    Task<Book> task = book.getBookById(bookId);
                    Book bk = await task;
                    if (bk != null)
                    {
                        // MessageBox.Show("Data retrieved successfully!");
                        dataGridViewB_1.DataSource = new List<Book> { bk };
                    }

                   else
                    {
                        errorProvider1.SetError(getBookIdBtn, "Book with this id does not exist.");
                        return;
                    }
                }

            }

            else
            {
                errorProvider1.SetError(getBookIdBtn, "Please enter the id field.");
                return;
            }

        }

        private void getBook_title_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = getBook_title.Text.Trim();

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(getBook_title, "Please enter the book's title.");
                e.Cancel = true;
                return;
            }

            if (inputText.Length > 100)
            {
                errorProvider1.SetError(getBook_title, "Title should not exceed 100 characters.");
                e.Cancel = true;
                return;
            }
        }

        private async void getBookTitleBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(getBook_title.Text))
            {
                Book_BL book = new Book_BL();
                Task<Book> task = book.getBookByTitle(getBook_title.Text);
                Book bk = await task;
                if (bk != null)
                {
                    //MessageBox.Show("Data retrieved successfully!");
                    dataGridViewB_2.DataSource = new List<Book> { bk };
                }

                else
                {
                    errorProvider1.SetError(getBookTitleBtn, "Book with this title does not exist.");
                    return;
                }
            }

            else
            {
                errorProvider1.SetError(getBookTitleBtn, "Please enter the Title field.");
                return;
            }



        }

        private void getBook_genre_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = getBook_genre.Text.Trim();

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(getBook_genre, "Please enter the book's genre.");
                e.Cancel = true;
                return;
            }

            if (inputText.Length > 50)
            {
                errorProvider1.SetError(getBook_genre, "Genre should not exceed 50 characters.");
                e.Cancel = true;
                return;
            }

        }

        private async void getBookGenreBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(getBook_genre.Text))
            {
                Book_BL book = new Book_BL();
                Task<IEnumerable<Book>> task = book.getBookByGenre(getBook_genre.Text);
                IEnumerable<Book> books = await task;
                if (books != null && books.Any())
                {
                    //MessageBox.Show("Data retrieved successfully!");
                    dataGridViewB_3.DataSource = books.ToList();
                }
                else
                {
                    //MessageBox.Show("hello");
                    errorProvider1.SetError(getBookGenreBtn, "Book (s) with this genre does not exist.");
                    return;
                }

            }

            else
            {
                errorProvider1.SetError(getBookGenreBtn, "Please enter the Genre field.");
                return;
            }

        }

        private async void viewBooksBtn_Click(object sender, EventArgs e)
        {
            Book_BL book = new Book_BL();
            Task<IEnumerable<Book>> task = book.getAllBooks();
            IEnumerable<Book> books = await task;
            if (books != null)
            {
                //MessageBox.Show("Data retrieved successfully!");
                dataGridViewB_4.DataSource = books.ToList();
            }
            else
            {
                errorProvider1.SetError(viewBooksBtn, "No Book(s) exist.");
                return;
            }

        }

        private void delBookId_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = delBookId.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(delBookId, "Please enter a book id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int bookId))
            {
                errorProvider1.SetError(delBookId, "Please enter a valid integer for the Book ID.");
                e.Cancel = true;
                return;
            }

            if (bookId < 1 || bookId > 1000)
            {
                errorProvider1.SetError(delBookId, "Please enter an integer between 1 and 1000 for the book ID.");
                e.Cancel = true;
            }
        }

        private async void delBookBtn_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("hiii");

            if (!string.IsNullOrEmpty(delBookId.Text))
            {
                Book_BL book = new Book_BL();

                if (int.TryParse(delBookId.Text, out int bookId))
                {
                    bool deletionSuccessful = await book.DeleteBookById(bookId);
                    if (deletionSuccessful)
                    {
                        messagelbl2.Text = "Deleted Successfully !";
                       // MessageBox.Show("hiii");
                    }
                    else
                    {
                      
                        messagelbl2.Text = "An error occured!";
                        Console.WriteLine("Failed to delete customer.");
                    }

                }

            }

            else
            {
                errorProvider1.SetError(delBookBtn, "Please enter the id field.");
                return;
            }
        }

        private void updateBookId_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = updateBookId.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(updateBookId, "Please enter a book id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int bookId))
            {
                errorProvider1.SetError(updateBookId, "Please enter a valid integer for the Book ID.");
                e.Cancel = true;
                return;
            }

            if (bookId < 1 || bookId > 1000)
            {
                errorProvider1.SetError(updateBookId, "Please enter an integer between 1 and 1000 for the book ID.");
                e.Cancel = true;
            }
        }

        private void updateNbCopy_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = updateNbCopy.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(updateNbCopy, "Please enter the number of copies available for this book.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int nb))
            {
                errorProvider1.SetError(updateNbCopy, "Please enter a valid integer for the number of copies available.");
                e.Cancel = true;
                return;
            }

            if (nb < 1)
            {
                errorProvider1.SetError(updateNbCopy, "Please enter an integer larger than 1 for the number of copies available.");
                e.Cancel = true;
            }
        }

        private async void updateBtn_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(updateBookId.Text) && !string.IsNullOrEmpty(updateNbCopy.Text))
            {
                Book_BL book = new Book_BL();

                if (int.TryParse(updateBookId.Text, out int bookId) && int.TryParse(updateNbCopy.Text, out int nb))
                {
                    bool updateSuccessful = await book.UpdateNumOfCopies(bookId, nb);
                    if (updateSuccessful)
                    {
                        messagelbl3.Text = "Updated Successfully !";
                        // MessageBox.Show("hiii");
                    }
                    else
                    {
                        
                        messagelbl3.Text = "An error occured!";
                      
                    }

                }

            }

            else
            {
                errorProvider1.SetError(updateBtn, "Please enter the id and nb of copies fields.");
                return;
            }
        }

       /* private void Rent_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Rent_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Rent_id, "Please enter a Transaction id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int TId))
            {
                errorProvider1.SetError(Rent_id, "Please enter a valid integer for the Transation ID.");
                e.Cancel = true;
                return;
            }

            if (TId < 1)
            {
                errorProvider1.SetError(Rent_id, "Please enter a positive number for Transaction ID.");
                e.Cancel = true;
            }
        }*/

        private void Rent_Book_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Rent_Book_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Rent_Book_id, "Please enter a book id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int bookId))
            {
                errorProvider1.SetError(Rent_Book_id, "Please enter a valid integer for the Book ID.");
                e.Cancel = true;
                return;
            }

            if (bookId < 1 || bookId > 1000)
            {
                errorProvider1.SetError(Rent_Book_id, "Please enter an integer between 1 and 1000 for the book ID.");
                e.Cancel = true;
            }
        }

        private void Rent_Customer_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Rent_Customer_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Rent_Customer_id, "Please enter a customer id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int customerId))
            {
                errorProvider1.SetError(Rent_Customer_id, "Please enter a valid integer for the customer ID.");
                e.Cancel = true;
                return;
            }

            if (customerId < 1)
            {
                errorProvider1.SetError(Rent_Customer_id, "Please enter a positive integer for the customer ID.");
                e.Cancel = true;
            }
        }

        private void Rent_E_username_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Rent_E_username.Text.Trim();

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Rent_E_username, "Please enter the Librarian Username.");
                e.Cancel = true;
                return;
            }

            if (inputText.Length > 50)
            {
                errorProvider1.SetError(Rent_E_username, "Username should not exceed 50 characters.");
                e.Cancel = true;
                return;
            }
        }

        private void Rent_Start_Date_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string dob = Rent_Start_Date.Text.Trim();

            if (string.IsNullOrEmpty(dob))
            {
                errorProvider1.SetError(Rent_Start_Date, "Please enter a rent start date (mm-dd-yyyy).");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(dob, @"^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])-(19[2-9][0-9]|20[0-1][0-9]|202[0-3])$"))
            {
                errorProvider1.SetError(Rent_Start_Date, "Please enter a valid rent start date in the format mm-dd-yyyy.");
                e.Cancel = true;
                return;
            }
        }

        private void Rent_End_Date_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string dob = Rent_End_Date.Text.Trim();

            if (string.IsNullOrEmpty(dob))
            {
                errorProvider1.SetError(Rent_End_Date, "Please enter a rent end date (mm-dd-yyyy).");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(dob, @"^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])-(19[2-9][0-9]|20[0-1][0-9]|202[0-3])$"))
            {
                errorProvider1.SetError(Rent_End_Date, "Please enter a valid rent end date in the format mm-dd-yyyy.");
                e.Cancel = true;
                return;
            }
        }

        private async void Submit_Rent_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Rent_Start_Date.Text) && !string.IsNullOrEmpty(Rent_End_Date.Text)
                 && !string.IsNullOrEmpty(Rent_Customer_id.Text) &&
                !string.IsNullOrEmpty(Rent_E_username.Text) && !string.IsNullOrEmpty(Rent_Book_id.Text))
                
            {

                Rent_Book rbook = new Rent_Book();
                

                if (int.TryParse(Rent_Customer_id.Text, out int cust))
                {
                    rbook.Customer_id_Rent = cust;
                }

                if (int.TryParse(Rent_Book_id.Text, out int BID))
                {
                    rbook.BookId = BID;
                }

                if (DateTime.TryParse(Rent_End_Date.Text, out DateTime d))
                {
                    rbook.Rent_End_Date = d;
                }

                if (DateTime.TryParse(Rent_Start_Date.Text, out DateTime date))
                {
                    rbook.Rent_Start_Date = date;
                }

                rbook.E_Username_Rent = Rent_E_username.Text;

                Rent_Book_BL rBook = new Rent_Book_BL();

                await rBook.AddRentedBook(rbook);

                Book_BL book = new Book_BL();
                await book.decreaseCopies(BID);
                int nb = await book.GetNbAvailableById(BID);

                decimal price = await book.GetRentPriceById(BID);

                messagelbl5.Text = "Number of copies for this book has become "+ nb;
                messagelbl6.Text = "Rent Price is: " + price+"$";

            }

            else
            {
                errorProvider1.SetError(Submit_Rent, "Please enter all fieldls.");
                return;
            }
        }

        private async void checkBtn_Click(object sender, EventArgs e)
        {
            Book_BL book = new Book_BL();

            // increase copies for retrieved rented books
            await book.IncreaseCopiesAfterRent();

            if (int.TryParse(Rent_Book_id.Text, out int bookId)){

                int nb = await book.GetNbAvailableById(bookId);
                if (nb <= 0)
                {
                    Submit_Rent.Enabled = false;
                    messagelbl4.Text = "There is no available copies of this book anymore.";
                }
                else
                {
                    Submit_Rent.Enabled = true;
                    messagelbl4.Text = "There is "+ nb + " available copies of this book.";
                }

            }

            
        }

        private void RentCustId_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = RentCustId.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(RentCustId, "Please enter a customer id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int customerId))
            {
                errorProvider1.SetError(RentCustId, "Please enter a valid integer for the customer ID.");
                e.Cancel = true;
                return;
            }

            if (customerId < 1)
            {
                errorProvider1.SetError(RentCustId, "Please enter a positive integer for the customer ID.");
                e.Cancel = true;
            }

        }

        private async void getRentedByIdBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(RentCustId.Text))
            {
                //MessageBox.Show("hi");
                Rent_Book_BL rbook = new Rent_Book_BL();

                if (int.TryParse(RentCustId.Text, out int customerId))
                {
                    Task<IEnumerable<Rent_Book>>  task = rbook.getRentedBookByCustId(customerId);
                    IEnumerable < Rent_Book > rbooks = await task;
                    if (rbooks != null)
                    {
                        // MessageBox.Show("Data retrieved successfully!");
                        dataGridView_R1.DataSource = rbooks.ToList();
                    }
                    else
                    {
                        MessageBox.Show("Error occurred while retrieving data.");
                    }
                }

            }

            else
            {
                errorProvider1.SetError(getRentedByIdBtn, "Please enter the id field.");
                return;
            }


        }

        private async void viewAllRentedBtn_Click(object sender, EventArgs e)
        {
                Rent_Book_BL rbook = new Rent_Book_BL();

            
                Task<IEnumerable<Rent_Book>> task = rbook.getAllRentedBooks();
                IEnumerable<Rent_Book> rbooks = await task;
                if (rbooks != null)
                {
                    // MessageBox.Show("Data retrieved successfully!");
                    dataGridView_R2.DataSource = rbooks.ToList();
                }
                else
                {
                    MessageBox.Show("Error occurred while retrieving data.");
                }
        }

        private void Sell_Book_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Sell_Book_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Sell_Book_id, "Please enter a book id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int bookId))
            {
                errorProvider1.SetError(Sell_Book_id, "Please enter a valid integer for the Book ID.");
                e.Cancel = true;
                return;
            }

            if (bookId < 1 || bookId > 1000)
            {
                errorProvider1.SetError(Sell_Book_id, "Please enter an integer between 1 and 1000 for the book ID.");
                e.Cancel = true;
            }
        }

        private void Sell_Customer_id_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Sell_Customer_id.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Sell_Customer_id, "Please enter a customer id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int customerId))
            {
                errorProvider1.SetError(Sell_Customer_id, "Please enter a valid integer for the customer ID.");
                e.Cancel = true;
                return;
            }

            if (customerId < 1)
            {
                errorProvider1.SetError(Sell_Customer_id, "Please enter a positive integer for the customer ID.");
                e.Cancel = true;
            }
        }

        private void Sell_E_username_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = Sell_E_username.Text.Trim();

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(Sell_E_username, "Please enter the Librarian Username.");
                e.Cancel = true;
                return;
            }

            if (inputText.Length > 50)
            {
                errorProvider1.SetError(Sell_E_username, "Username should not exceed 50 characters.");
                e.Cancel = true;
                return;
            }
        }

        private void Sell_Date_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();

            string dob = Sell_Date.Text.Trim();

            if (string.IsNullOrEmpty(dob))
            {
                errorProvider1.SetError(Sell_Date, "Please enter a rent end date (mm-dd-yyyy).");
                e.Cancel = true;
                return;
            }

            if (!Regex.IsMatch(dob, @"^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])-(202[3-9]|20[3-9][0-9]|2[1-9][0-9]{2}|[3-9][0-9]{3})$"))

            {
                errorProvider1.SetError(Sell_Date, "Please enter a valid sale date (>2023) in the format mm-dd-yyyy.");
                e.Cancel = true;
                return;
            }
        }

        private async void check_saleBtn_Click(object sender, EventArgs e)
        {
            Book_BL book = new Book_BL();

            // increase copies for retrieved rented books
            await book.IncreaseCopiesAfterRent();

            if (int.TryParse(Sell_Book_id.Text, out int bookId))
            {

                int nb = await book.GetNbAvailableById(bookId);
                if (nb <= 0)
                {
                    submitSaleBtn.Enabled = false;
                    messagelbl7.Text = "There is no available copies of this book anymore.";
                }
                else
                {
                    submitSaleBtn.Enabled = true;
                    messagelbl7.Text = "There is " + nb + " available copies of this book.";
                }

            }
        }

        private async void submitSaleBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Sell_Date.Text) && !string.IsNullOrEmpty(Sell_Book_id.Text) &&
                !string.IsNullOrEmpty(Sell_Customer_id.Text) && !string.IsNullOrEmpty(Sell_E_username.Text))
              

            {

                Sell_Book sbook = new Sell_Book();



                if (int.TryParse(Sell_Customer_id.Text, out int cust))
                {
                    sbook.Customer_id_Sell = cust;
                }

                if (int.TryParse(Sell_Book_id.Text, out int BID))
                {
                    sbook.BookId = BID;
                }

                if (DateTime.TryParse(Sell_Date.Text, out DateTime d))
                {
                    sbook.saleDate = d;
                }

               

                sbook.E_username_Sell = Sell_E_username.Text;

                Sell_Book_BL sBook = new Sell_Book_BL();

                await sBook.AddSoldBook(sbook);

                Book_BL book = new Book_BL();
                await book.decreaseCopies(BID);
                int nb = await book.GetNbAvailableById(BID);

                decimal price = await book.GetSellPriceById(BID);

                messagelbl8.Text = "Number of copies for this book has become " + nb;
                messagelbl9.Text = "Sell Price is: " + price+"$";

            }

            else
            {
                errorProvider1.SetError(submitSaleBtn, "Please enter all fieldls.");
                return;
            }
        }

        private void getSellCustId_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            errorProvider1.Clear();
            string inputText = getSellCustId.Text;

            if (string.IsNullOrEmpty(inputText))
            {
                errorProvider1.SetError(getSellCustId, "Please enter a customer id.");
                e.Cancel = true;
                return;
            }

            if (!int.TryParse(inputText, out int customerId))
            {
                errorProvider1.SetError(getSellCustId, "Please enter a valid integer for the customer ID.");
                e.Cancel = true;
                return;
            }

            if (customerId < 1)
            {
                errorProvider1.SetError(getSellCustId, "Please enter a positive integer for the customer ID.");
                e.Cancel = true;
            }
        }

        private async void submit_getSell_custId_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(getSellCustId.Text))
            {
                //MessageBox.Show("hi");
                Sell_Book_BL sbook = new Sell_Book_BL();

                if (int.TryParse(getSellCustId.Text, out int customerId))
                {
                    Task<IEnumerable<Sell_Book>> task = sbook.getSoldBookByCustId(customerId);
                    IEnumerable<Sell_Book> sbooks = await task;
                    if (sbooks != null)
                    {
                        // MessageBox.Show("Data retrieved successfully!");
                        dataGridView_S1.DataSource = sbooks.ToList();
                    }
                    else
                    {
                        MessageBox.Show("Error occurred while retrieving data.");
                    }
                }

            }

            else
            {
                errorProvider1.SetError(submit_getSell_custId, "Please enter the id field.");
                return;
            }
        }

        private async void viewSoldBtn_Click(object sender, EventArgs e)
        {
            Sell_Book_BL sbook = new Sell_Book_BL();


            Task<IEnumerable<Sell_Book>> task = sbook.getAllSoldBooks();
            IEnumerable<Sell_Book> sbooks = await task;
            if (sbooks != null)
            {
                // MessageBox.Show("Data retrieved successfully!");
                dataGridView_S2.DataSource = sbooks.ToList();
            }
            else
            {
                MessageBox.Show("Error occurred while retrieving data.");
            }
        }
    }
}

