﻿using System.Drawing;
using System.Windows.Forms;

namespace LibraryWinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /// 


        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            this.MainTabControl = new System.Windows.Forms.TabControl();
            this.customerTab1 = new System.Windows.Forms.TabPage();
            this.CustomerTabControl = new System.Windows.Forms.TabControl();
            this.addCustTab1 = new System.Windows.Forms.TabPage();
            this.AddCustBtn = new System.Windows.Forms.Button();
            this.InfoTableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.customerUsername = new System.Windows.Forms.Label();
            this.DOB = new System.Windows.Forms.TextBox();
            this.dateOfBirth = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.TextBox();
            this.add_ress = new System.Windows.Forms.Label();
            this.PhoneNb = new System.Windows.Forms.Label();
            this.PhoneNumber = new System.Windows.Forms.TextBox();
            this.Customer_Username = new System.Windows.Forms.TextBox();
            this.FirstName = new System.Windows.Forms.Label();
            this.First_Name = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.Label();
            this.Last_Name = new System.Windows.Forms.TextBox();
            this.e_mail = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.TextBox();
            this.AddCustTableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.AddCustLabel = new System.Windows.Forms.Label();
            this.DateLabel = new System.Windows.Forms.Label();
            this.datelabel2 = new System.Windows.Forms.Label();
            this.getCustTab2 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.ViewAllBtn = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.get_Customer_id = new System.Windows.Forms.TextBox();
            this.submitCustId = new System.Windows.Forms.Button();
            this.getCustTableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.DateLabel3 = new System.Windows.Forms.Label();
            this.dateLabel4 = new System.Windows.Forms.Label();
            this.delCustTab3 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.messagelbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.custId_delete = new System.Windows.Forms.TextBox();
            this.submitBtnDlt = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dateLabel6 = new System.Windows.Forms.Label();
            this.bookTab2 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.dateLabel7 = new System.Windows.Forms.Label();
            this.addBookBtn = new System.Windows.Forms.Button();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.NumberOfCopies_Available = new System.Windows.Forms.TextBox();
            this.Rent_Price = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Sell_Price = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Published_Date = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ISBN = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.Genre = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.author_id = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.publisher_id = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel_1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.label23 = new System.Windows.Forms.Label();
            this.getBookGenreBtn = new System.Windows.Forms.Button();
            this.getBook_genre = new System.Windows.Forms.TextBox();
            this.dataGridViewB_3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewB_4 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.label24 = new System.Windows.Forms.Label();
            this.viewBooksBtn = new System.Windows.Forms.Button();
            this.dataGridViewB_2 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.label21 = new System.Windows.Forms.Label();
            this.getBook_title = new System.Windows.Forms.TextBox();
            this.getBookTitleBtn = new System.Windows.Forms.Button();
            this.dataGridViewB_1 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.label22 = new System.Windows.Forms.Label();
            this.getBook_id = new System.Windows.Forms.TextBox();
            this.getBookIdBtn = new System.Windows.Forms.Button();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.dateLabel8 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.messagelbl2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.label28 = new System.Windows.Forms.Label();
            this.delBookId = new System.Windows.Forms.TextBox();
            this.delBookBtn = new System.Windows.Forms.Button();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.dateLabel9 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.messagelbl3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.label31 = new System.Windows.Forms.Label();
            this.updateBookId = new System.Windows.Forms.TextBox();
            this.updateBtn = new System.Windows.Forms.Button();
            this.updateNbCopy = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.label27 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.dateLabel10 = new System.Windows.Forms.Label();
            this.transactionTab3 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.messagelbl6 = new System.Windows.Forms.Label();
            this.messagelbl5 = new System.Windows.Forms.Label();
            this.messagelbl4 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.checkBtn = new System.Windows.Forms.Button();
            this.Submit_Rent = new System.Windows.Forms.Button();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.Rent_Start_Date = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.Rent_Customer_id = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.Rent_End_Date = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.Rent_Book_id = new System.Windows.Forms.TextBox();
            this.Rent_E_username = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.dateLabel11 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_R2 = new System.Windows.Forms.DataGridView();
            this.dataGridView_R1 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.label43 = new System.Windows.Forms.Label();
            this.viewAllRentedBtn = new System.Windows.Forms.Button();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.label44 = new System.Windows.Forms.Label();
            this.RentCustId = new System.Windows.Forms.TextBox();
            this.getRentedByIdBtn = new System.Windows.Forms.Button();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.dateLabel12 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.submitSaleBtn = new System.Windows.Forms.Button();
            this.check_saleBtn = new System.Windows.Forms.Button();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.messagelbl9 = new System.Windows.Forms.Label();
            this.messagelbl8 = new System.Windows.Forms.Label();
            this.messagelbl7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.label48 = new System.Windows.Forms.Label();
            this.Sell_E_username = new System.Windows.Forms.TextBox();
            this.Sell_Date = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.Sell_Book_id = new System.Windows.Forms.TextBox();
            this.Sell_Customer_id = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.label39 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.dateLabel13 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dataGridView_S2 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.label55 = new System.Windows.Forms.Label();
            this.viewSoldBtn = new System.Windows.Forms.Button();
            this.dataGridView_S1 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.label54 = new System.Windows.Forms.Label();
            this.getSellCustId = new System.Windows.Forms.TextBox();
            this.submit_getSell_custId = new System.Windows.Forms.Button();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.label47 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.dateLabel14 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.MainTabControl.SuspendLayout();
            this.customerTab1.SuspendLayout();
            this.CustomerTabControl.SuspendLayout();
            this.addCustTab1.SuspendLayout();
            this.InfoTableLayoutPanel2.SuspendLayout();
            this.AddCustTableLayoutPanel1.SuspendLayout();
            this.getCustTab2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.getCustTableLayoutPanel1.SuspendLayout();
            this.delCustTab3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.bookTab2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel_1.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB_4)).BeginInit();
            this.tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB_2)).BeginInit();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB_1)).BeginInit();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.transactionTab3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_R2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_R1)).BeginInit();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_S2)).BeginInit();
            this.tableLayoutPanel30.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_S1)).BeginInit();
            this.tableLayoutPanel29.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // MainTabControl
            // 
            this.MainTabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTabControl.Controls.Add(this.customerTab1);
            this.MainTabControl.Controls.Add(this.bookTab2);
            this.MainTabControl.Controls.Add(this.transactionTab3);
            this.MainTabControl.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.MainTabControl.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.MainTabControl.Location = new System.Drawing.Point(0, 0);
            this.MainTabControl.Multiline = true;
            this.MainTabControl.Name = "MainTabControl";
            this.MainTabControl.Padding = new System.Drawing.Point(8, 4);
            this.MainTabControl.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MainTabControl.SelectedIndex = 0;
            this.MainTabControl.Size = new System.Drawing.Size(1039, 568);
            this.MainTabControl.TabIndex = 1;
            // 
            // customerTab1
            // 
            this.customerTab1.BackColor = System.Drawing.Color.White;
            this.customerTab1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.customerTab1.Controls.Add(this.CustomerTabControl);
            this.customerTab1.Font = new System.Drawing.Font("Sans Serif Collection", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerTab1.Location = new System.Drawing.Point(4, 36);
            this.customerTab1.Name = "customerTab1";
            this.customerTab1.Padding = new System.Windows.Forms.Padding(3);
            this.customerTab1.Size = new System.Drawing.Size(1031, 528);
            this.customerTab1.TabIndex = 0;
            this.customerTab1.Text = "Customers";
            // 
            // CustomerTabControl
            // 
            this.CustomerTabControl.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.CustomerTabControl.Controls.Add(this.addCustTab1);
            this.CustomerTabControl.Controls.Add(this.getCustTab2);
            this.CustomerTabControl.Controls.Add(this.delCustTab3);
            this.CustomerTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CustomerTabControl.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            this.CustomerTabControl.Location = new System.Drawing.Point(3, 3);
            this.CustomerTabControl.Multiline = true;
            this.CustomerTabControl.Name = "CustomerTabControl";
            this.CustomerTabControl.SelectedIndex = 0;
            this.CustomerTabControl.Size = new System.Drawing.Size(1023, 520);
            this.CustomerTabControl.TabIndex = 0;
            // 
            // addCustTab1
            // 
            this.addCustTab1.AutoScroll = true;
            this.addCustTab1.BackColor = System.Drawing.Color.Transparent;
            this.addCustTab1.Controls.Add(this.AddCustBtn);
            this.addCustTab1.Controls.Add(this.InfoTableLayoutPanel2);
            this.addCustTab1.Controls.Add(this.AddCustTableLayoutPanel1);
            this.addCustTab1.Location = new System.Drawing.Point(28, 4);
            this.addCustTab1.Name = "addCustTab1";
            this.addCustTab1.Padding = new System.Windows.Forms.Padding(3);
            this.addCustTab1.Size = new System.Drawing.Size(991, 512);
            this.addCustTab1.TabIndex = 0;
            this.addCustTab1.Text = "Add New Customer";
            // 
            // AddCustBtn
            // 
            this.AddCustBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddCustBtn.BackColor = System.Drawing.Color.LightBlue;
            this.AddCustBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddCustBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddCustBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.AddCustBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.AddCustBtn.Location = new System.Drawing.Point(348, 418);
            this.AddCustBtn.Name = "AddCustBtn";
            this.AddCustBtn.Size = new System.Drawing.Size(185, 41);
            this.AddCustBtn.TabIndex = 2;
            this.AddCustBtn.Text = "Submit";
            this.AddCustBtn.UseVisualStyleBackColor = false;
            this.AddCustBtn.Click += new System.EventHandler(this.AddCustBtn_Click);
            // 
            // InfoTableLayoutPanel2
            // 
            this.InfoTableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InfoTableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.InfoTableLayoutPanel2.ColumnCount = 5;
            this.InfoTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.031F));
            this.InfoTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.9021F));
            this.InfoTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.26269F));
            this.InfoTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.68657F));
            this.InfoTableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.11764F));
            this.InfoTableLayoutPanel2.Controls.Add(this.customerUsername, 2, 0);
            this.InfoTableLayoutPanel2.Controls.Add(this.DOB, 3, 1);
            this.InfoTableLayoutPanel2.Controls.Add(this.dateOfBirth, 2, 1);
            this.InfoTableLayoutPanel2.Controls.Add(this.Address, 3, 2);
            this.InfoTableLayoutPanel2.Controls.Add(this.add_ress, 2, 2);
            this.InfoTableLayoutPanel2.Controls.Add(this.PhoneNb, 0, 3);
            this.InfoTableLayoutPanel2.Controls.Add(this.PhoneNumber, 1, 3);
            this.InfoTableLayoutPanel2.Controls.Add(this.Customer_Username, 3, 0);
            this.InfoTableLayoutPanel2.Controls.Add(this.FirstName, 0, 0);
            this.InfoTableLayoutPanel2.Controls.Add(this.First_Name, 1, 0);
            this.InfoTableLayoutPanel2.Controls.Add(this.LastName, 0, 1);
            this.InfoTableLayoutPanel2.Controls.Add(this.Last_Name, 1, 1);
            this.InfoTableLayoutPanel2.Controls.Add(this.e_mail, 0, 2);
            this.InfoTableLayoutPanel2.Controls.Add(this.Email, 1, 2);
            this.InfoTableLayoutPanel2.Location = new System.Drawing.Point(0, 133);
            this.InfoTableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.InfoTableLayoutPanel2.Name = "InfoTableLayoutPanel2";
            this.InfoTableLayoutPanel2.Padding = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.InfoTableLayoutPanel2.RowCount = 4;
            this.InfoTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.InfoTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.InfoTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.InfoTableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.InfoTableLayoutPanel2.Size = new System.Drawing.Size(1014, 241);
            this.InfoTableLayoutPanel2.TabIndex = 1;
            // 
            // customerUsername
            // 
            this.customerUsername.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.customerUsername.AutoSize = true;
            this.customerUsername.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.customerUsername.ForeColor = System.Drawing.Color.MidnightBlue;
            this.customerUsername.Location = new System.Drawing.Point(459, 7);
            this.customerUsername.Name = "customerUsername";
            this.customerUsername.Size = new System.Drawing.Size(102, 46);
            this.customerUsername.TabIndex = 6;
            this.customerUsername.Text = "Customer Username:";
            // 
            // DOB
            // 
            this.DOB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.DOB.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.DOB.Location = new System.Drawing.Point(567, 77);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(232, 26);
            this.DOB.TabIndex = 11;
            this.DOB.Validating += new System.ComponentModel.CancelEventHandler(this.DOB_Validating);
            // 
            // dateOfBirth
            // 
            this.dateOfBirth.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.dateOfBirth.AutoSize = true;
            this.dateOfBirth.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateOfBirth.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateOfBirth.Location = new System.Drawing.Point(433, 78);
            this.dateOfBirth.Name = "dateOfBirth";
            this.dateOfBirth.Size = new System.Drawing.Size(128, 23);
            this.dateOfBirth.TabIndex = 4;
            this.dateOfBirth.Text = "Date of Birth:";
            // 
            // Address
            // 
            this.Address.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Address.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Address.Location = new System.Drawing.Point(567, 138);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(232, 26);
            this.Address.TabIndex = 13;
            this.Address.Validating += new System.ComponentModel.CancelEventHandler(this.Address_Validating);
            // 
            // add_ress
            // 
            this.add_ress.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.add_ress.AutoSize = true;
            this.add_ress.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.add_ress.ForeColor = System.Drawing.Color.MidnightBlue;
            this.add_ress.Location = new System.Drawing.Point(476, 139);
            this.add_ress.Name = "add_ress";
            this.add_ress.Size = new System.Drawing.Size(85, 23);
            this.add_ress.TabIndex = 7;
            this.add_ress.Text = "Address:";
            // 
            // PhoneNb
            // 
            this.PhoneNb.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.PhoneNb.AutoSize = true;
            this.PhoneNb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.PhoneNb.ForeColor = System.Drawing.Color.MidnightBlue;
            this.PhoneNb.Location = new System.Drawing.Point(47, 200);
            this.PhoneNb.Name = "PhoneNb";
            this.PhoneNb.Size = new System.Drawing.Size(141, 23);
            this.PhoneNb.TabIndex = 5;
            this.PhoneNb.Text = "Phone Number:";
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.PhoneNumber.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.PhoneNumber.Location = new System.Drawing.Point(194, 198);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(214, 26);
            this.PhoneNumber.TabIndex = 9;
            this.PhoneNumber.Validating += new System.ComponentModel.CancelEventHandler(this.PhoneNumber_Validating);
            // 
            // Customer_Username
            // 
            this.Customer_Username.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Customer_Username.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Customer_Username.Location = new System.Drawing.Point(567, 17);
            this.Customer_Username.Name = "Customer_Username";
            this.Customer_Username.Size = new System.Drawing.Size(232, 26);
            this.Customer_Username.TabIndex = 15;
            this.Customer_Username.Validating += new System.ComponentModel.CancelEventHandler(this.Customer_Username_Validating);
            // 
            // FirstName
            // 
            this.FirstName.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.FirstName.AutoSize = true;
            this.FirstName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.FirstName.ForeColor = System.Drawing.Color.MidnightBlue;
            this.FirstName.Location = new System.Drawing.Point(78, 18);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(110, 23);
            this.FirstName.TabIndex = 1;
            this.FirstName.Text = "First Name:";
            // 
            // First_Name
            // 
            this.First_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.First_Name.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.First_Name.Location = new System.Drawing.Point(194, 17);
            this.First_Name.Name = "First_Name";
            this.First_Name.Size = new System.Drawing.Size(214, 26);
            this.First_Name.TabIndex = 10;
            this.First_Name.Validating += new System.ComponentModel.CancelEventHandler(this.First_Name_Validating);
            // 
            // LastName
            // 
            this.LastName.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LastName.AutoSize = true;
            this.LastName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.LastName.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LastName.Location = new System.Drawing.Point(79, 78);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(109, 23);
            this.LastName.TabIndex = 2;
            this.LastName.Text = "Last Name:";
            // 
            // Last_Name
            // 
            this.Last_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Last_Name.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Last_Name.Location = new System.Drawing.Point(194, 77);
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(214, 26);
            this.Last_Name.TabIndex = 12;
            this.Last_Name.Validating += new System.ComponentModel.CancelEventHandler(this.Last_Name_Validating);
            // 
            // e_mail
            // 
            this.e_mail.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.e_mail.AutoSize = true;
            this.e_mail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.e_mail.ForeColor = System.Drawing.Color.MidnightBlue;
            this.e_mail.Location = new System.Drawing.Point(123, 139);
            this.e_mail.Name = "e_mail";
            this.e_mail.Size = new System.Drawing.Size(65, 23);
            this.e_mail.TabIndex = 3;
            this.e_mail.Text = "Email:";
            // 
            // Email
            // 
            this.Email.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Email.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Email.Location = new System.Drawing.Point(194, 138);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(214, 26);
            this.Email.TabIndex = 14;
            this.Email.Validating += new System.ComponentModel.CancelEventHandler(this.Email_Validating);
            // 
            // AddCustTableLayoutPanel1
            // 
            this.AddCustTableLayoutPanel1.BackColor = System.Drawing.Color.LightBlue;
            this.AddCustTableLayoutPanel1.ColumnCount = 4;
            this.AddCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.AddCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.AddCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.AddCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 195F));
            this.AddCustTableLayoutPanel1.Controls.Add(this.AddCustLabel, 1, 0);
            this.AddCustTableLayoutPanel1.Controls.Add(this.DateLabel, 2, 0);
            this.AddCustTableLayoutPanel1.Controls.Add(this.datelabel2, 3, 0);
            this.AddCustTableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.AddCustTableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.AddCustTableLayoutPanel1.Name = "AddCustTableLayoutPanel1";
            this.AddCustTableLayoutPanel1.RowCount = 1;
            this.AddCustTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.AddCustTableLayoutPanel1.Size = new System.Drawing.Size(985, 48);
            this.AddCustTableLayoutPanel1.TabIndex = 0;
            // 
            // AddCustLabel
            // 
            this.AddCustLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddCustLabel.AutoSize = true;
            this.AddCustLabel.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.AddCustLabel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.AddCustLabel.Location = new System.Drawing.Point(330, 12);
            this.AddCustLabel.Name = "AddCustLabel";
            this.AddCustLabel.Size = new System.Drawing.Size(189, 23);
            this.AddCustLabel.TabIndex = 0;
            this.AddCustLabel.Text = "Add a New Customer";
            // 
            // DateLabel
            // 
            this.DateLabel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.DateLabel.AutoSize = true;
            this.DateLabel.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.DateLabel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.DateLabel.Location = new System.Drawing.Point(727, 12);
            this.DateLabel.Name = "DateLabel";
            this.DateLabel.Size = new System.Drawing.Size(58, 23);
            this.DateLabel.TabIndex = 1;
            this.DateLabel.Text = "Date:";
            this.DateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // datelabel2
            // 
            this.datelabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.datelabel2.AutoSize = true;
            this.datelabel2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.datelabel2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.datelabel2.Location = new System.Drawing.Point(791, 12);
            this.datelabel2.Name = "datelabel2";
            this.datelabel2.Size = new System.Drawing.Size(47, 23);
            this.datelabel2.TabIndex = 3;
            this.datelabel2.Text = "date";
            this.datelabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // getCustTab2
            // 
            this.getCustTab2.AutoScroll = true;
            this.getCustTab2.BackColor = System.Drawing.Color.Transparent;
            this.getCustTab2.Controls.Add(this.panel1);
            this.getCustTab2.Controls.Add(this.getCustTableLayoutPanel1);
            this.getCustTab2.Location = new System.Drawing.Point(28, 4);
            this.getCustTab2.Name = "getCustTab2";
            this.getCustTab2.Padding = new System.Windows.Forms.Padding(3);
            this.getCustTab2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.getCustTab2.Size = new System.Drawing.Size(991, 512);
            this.getCustTab2.TabIndex = 1;
            this.getCustTab2.Text = "Get Customer (s)";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(985, 458);
            this.panel1.TabIndex = 2;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle31.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridView2.ColumnHeadersHeight = 29;
            this.dataGridView2.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridView2.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridView2.Location = new System.Drawing.Point(-3, 285);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(979, 170);
            this.dataGridView2.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridView1.ColumnHeadersHeight = 29;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridView1.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridView1.Location = new System.Drawing.Point(0, 99);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle36.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(979, 58);
            this.dataGridView1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.35628F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.50319F));
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ViewAllBtn, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 222);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(988, 57);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label5.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label5.Location = new System.Drawing.Point(35, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(173, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "Get All Customers:";
            // 
            // ViewAllBtn
            // 
            this.ViewAllBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.ViewAllBtn.BackColor = System.Drawing.Color.LightBlue;
            this.ViewAllBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.ViewAllBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ViewAllBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.ViewAllBtn.Location = new System.Drawing.Point(214, 13);
            this.ViewAllBtn.Name = "ViewAllBtn";
            this.ViewAllBtn.Size = new System.Drawing.Size(204, 30);
            this.ViewAllBtn.TabIndex = 1;
            this.ViewAllBtn.Text = "View All";
            this.ViewAllBtn.UseVisualStyleBackColor = false;
            this.ViewAllBtn.Click += new System.EventHandler(this.ViewAllBtn_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.39122F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.14913F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.get_Customer_id, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.submitCustId, 2, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 34);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(979, 59);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label4.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label4.Location = new System.Drawing.Point(21, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(204, 23);
            this.label4.TabIndex = 0;
            this.label4.Text = "Enter the Customer id:";
            // 
            // get_Customer_id
            // 
            this.get_Customer_id.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.get_Customer_id.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.get_Customer_id.ForeColor = System.Drawing.Color.Black;
            this.get_Customer_id.Location = new System.Drawing.Point(231, 16);
            this.get_Customer_id.Name = "get_Customer_id";
            this.get_Customer_id.Size = new System.Drawing.Size(241, 26);
            this.get_Customer_id.TabIndex = 1;
            this.get_Customer_id.Validating += new System.ComponentModel.CancelEventHandler(this.get_Customer_id_Validating);
            // 
            // submitCustId
            // 
            this.submitCustId.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.submitCustId.BackColor = System.Drawing.Color.LightBlue;
            this.submitCustId.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.submitCustId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.submitCustId.ForeColor = System.Drawing.Color.MidnightBlue;
            this.submitCustId.Location = new System.Drawing.Point(486, 17);
            this.submitCustId.Name = "submitCustId";
            this.submitCustId.Size = new System.Drawing.Size(151, 25);
            this.submitCustId.TabIndex = 2;
            this.submitCustId.Text = "Submit";
            this.submitCustId.UseVisualStyleBackColor = false;
            this.submitCustId.Click += new System.EventHandler(this.submitCustId_Click);
            // 
            // getCustTableLayoutPanel1
            // 
            this.getCustTableLayoutPanel1.BackColor = System.Drawing.Color.LightBlue;
            this.getCustTableLayoutPanel1.ColumnCount = 4;
            this.getCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.getCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.getCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.getCustTableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 195F));
            this.getCustTableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.getCustTableLayoutPanel1.Controls.Add(this.DateLabel3, 2, 0);
            this.getCustTableLayoutPanel1.Controls.Add(this.dateLabel4, 3, 0);
            this.getCustTableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.getCustTableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.getCustTableLayoutPanel1.Name = "getCustTableLayoutPanel1";
            this.getCustTableLayoutPanel1.RowCount = 1;
            this.getCustTableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.getCustTableLayoutPanel1.Size = new System.Drawing.Size(985, 48);
            this.getCustTableLayoutPanel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(346, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Get Customer (s)";
            // 
            // DateLabel3
            // 
            this.DateLabel3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.DateLabel3.AutoSize = true;
            this.DateLabel3.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.DateLabel3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.DateLabel3.Location = new System.Drawing.Point(727, 12);
            this.DateLabel3.Name = "DateLabel3";
            this.DateLabel3.Size = new System.Drawing.Size(58, 23);
            this.DateLabel3.TabIndex = 1;
            this.DateLabel3.Text = "Date:";
            this.DateLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel4
            // 
            this.dateLabel4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel4.AutoSize = true;
            this.dateLabel4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel4.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel4.Location = new System.Drawing.Point(791, 12);
            this.dateLabel4.Name = "dateLabel4";
            this.dateLabel4.Size = new System.Drawing.Size(47, 23);
            this.dateLabel4.TabIndex = 2;
            this.dateLabel4.Text = "date";
            this.dateLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // delCustTab3
            // 
            this.delCustTab3.AutoScroll = true;
            this.delCustTab3.BackColor = System.Drawing.Color.Transparent;
            this.delCustTab3.Controls.Add(this.panel2);
            this.delCustTab3.Controls.Add(this.tableLayoutPanel5);
            this.delCustTab3.Controls.Add(this.tableLayoutPanel4);
            this.delCustTab3.Controls.Add(this.tableLayoutPanel3);
            this.delCustTab3.Location = new System.Drawing.Point(28, 4);
            this.delCustTab3.Name = "delCustTab3";
            this.delCustTab3.Size = new System.Drawing.Size(991, 512);
            this.delCustTab3.TabIndex = 2;
            this.delCustTab3.Text = "Delete Customer";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackgroundImage = global::LibraryWinForm.Properties.Resources.books;
            this.panel2.Location = new System.Drawing.Point(3, 189);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(979, 299);
            this.panel2.TabIndex = 7;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel5.Controls.Add(this.messagelbl, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 146);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(985, 37);
            this.tableLayoutPanel5.TabIndex = 6;
            // 
            // messagelbl
            // 
            this.messagelbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.messagelbl.AutoSize = true;
            this.messagelbl.BackColor = System.Drawing.Color.LightBlue;
            this.messagelbl.ForeColor = System.Drawing.Color.Red;
            this.messagelbl.Location = new System.Drawing.Point(3, 9);
            this.messagelbl.Name = "messagelbl";
            this.messagelbl.Size = new System.Drawing.Size(0, 19);
            this.messagelbl.TabIndex = 5;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.39122F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.14913F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.custId_delete, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.submitBtnDlt, 2, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 81);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(979, 59);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label6.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label6.Location = new System.Drawing.Point(21, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(204, 23);
            this.label6.TabIndex = 0;
            this.label6.Text = "Enter the Customer id:";
            // 
            // custId_delete
            // 
            this.custId_delete.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.custId_delete.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.custId_delete.ForeColor = System.Drawing.Color.Black;
            this.custId_delete.Location = new System.Drawing.Point(231, 16);
            this.custId_delete.Name = "custId_delete";
            this.custId_delete.Size = new System.Drawing.Size(241, 26);
            this.custId_delete.TabIndex = 1;
            this.custId_delete.Validating += new System.ComponentModel.CancelEventHandler(this.custId_delete_Validating);
            // 
            // submitBtnDlt
            // 
            this.submitBtnDlt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.submitBtnDlt.BackColor = System.Drawing.Color.LightBlue;
            this.submitBtnDlt.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.submitBtnDlt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.submitBtnDlt.ForeColor = System.Drawing.Color.MidnightBlue;
            this.submitBtnDlt.Location = new System.Drawing.Point(486, 17);
            this.submitBtnDlt.Name = "submitBtnDlt";
            this.submitBtnDlt.Size = new System.Drawing.Size(151, 25);
            this.submitBtnDlt.TabIndex = 2;
            this.submitBtnDlt.Text = "Delete Customer";
            this.submitBtnDlt.UseVisualStyleBackColor = false;
            this.submitBtnDlt.Click += new System.EventHandler(this.submitBtnDlt_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 193F));
            this.tableLayoutPanel3.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.dateLabel6, 3, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(991, 48);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label2.Location = new System.Drawing.Point(343, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "Delete A Customer";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label3.Location = new System.Drawing.Point(735, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 23);
            this.label3.TabIndex = 1;
            this.label3.Text = "Date:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel6
            // 
            this.dateLabel6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel6.AutoSize = true;
            this.dateLabel6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel6.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel6.Location = new System.Drawing.Point(799, 12);
            this.dateLabel6.Name = "dateLabel6";
            this.dateLabel6.Size = new System.Drawing.Size(47, 23);
            this.dateLabel6.TabIndex = 2;
            this.dateLabel6.Text = "date";
            this.dateLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bookTab2
            // 
            this.bookTab2.BackColor = System.Drawing.Color.White;
            this.bookTab2.Controls.Add(this.tabControl1);
            this.bookTab2.Font = new System.Drawing.Font("Sans Serif Collection", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookTab2.Location = new System.Drawing.Point(4, 36);
            this.bookTab2.Name = "bookTab2";
            this.bookTab2.Padding = new System.Windows.Forms.Padding(3);
            this.bookTab2.Size = new System.Drawing.Size(1031, 528);
            this.bookTab2.TabIndex = 1;
            this.bookTab2.Text = "Books";
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1025, 522);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage5
            // 
            this.tabPage5.AutoScroll = true;
            this.tabPage5.BackColor = System.Drawing.Color.Transparent;
            this.tabPage5.Controls.Add(this.tableLayoutPanel7);
            this.tabPage5.Controls.Add(this.addBookBtn);
            this.tabPage5.Controls.Add(this.tableLayoutPanel6);
            this.tabPage5.Location = new System.Drawing.Point(28, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(993, 514);
            this.tabPage5.TabIndex = 3;
            this.tabPage5.Text = "Add New Book";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel7.ColumnCount = 4;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 193F));
            this.tableLayoutPanel7.Controls.Add(this.label15, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.label16, 2, 0);
            this.tableLayoutPanel7.Controls.Add(this.dateLabel7, 3, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(993, 48);
            this.tableLayoutPanel7.TabIndex = 5;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label15.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label15.Location = new System.Drawing.Point(354, 12);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(151, 23);
            this.label15.TabIndex = 0;
            this.label15.Text = "Add a New Book";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label16.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label16.Location = new System.Drawing.Point(737, 12);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 23);
            this.label16.TabIndex = 1;
            this.label16.Text = "Date:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel7
            // 
            this.dateLabel7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel7.AutoSize = true;
            this.dateLabel7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel7.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel7.Location = new System.Drawing.Point(801, 12);
            this.dateLabel7.Name = "dateLabel7";
            this.dateLabel7.Size = new System.Drawing.Size(47, 23);
            this.dateLabel7.TabIndex = 3;
            this.dateLabel7.Text = "date";
            this.dateLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // addBookBtn
            // 
            this.addBookBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addBookBtn.BackColor = System.Drawing.Color.LightBlue;
            this.addBookBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addBookBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addBookBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.addBookBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.addBookBtn.Location = new System.Drawing.Point(368, 434);
            this.addBookBtn.Name = "addBookBtn";
            this.addBookBtn.Size = new System.Drawing.Size(185, 41);
            this.addBookBtn.TabIndex = 4;
            this.addBookBtn.Text = "Submit";
            this.addBookBtn.UseVisualStyleBackColor = false;
            this.addBookBtn.Click += new System.EventHandler(this.addBookBtn_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel6.ColumnCount = 5;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.08549F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.96819F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.30815F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.75746F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.17893F));
            this.tableLayoutPanel6.Controls.Add(this.label7, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.NumberOfCopies_Available, 3, 3);
            this.tableLayoutPanel6.Controls.Add(this.Rent_Price, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this.label11, 2, 1);
            this.tableLayoutPanel6.Controls.Add(this.Sell_Price, 3, 2);
            this.tableLayoutPanel6.Controls.Add(this.label12, 2, 2);
            this.tableLayoutPanel6.Controls.Add(this.label13, 2, 3);
            this.tableLayoutPanel6.Controls.Add(this.Published_Date, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.ISBN, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label10, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.Title, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.label14, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.Genre, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.label17, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.author_id, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.label18, 0, 4);
            this.tableLayoutPanel6.Controls.Add(this.publisher_id, 1, 4);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 78);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.Padding = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.tableLayoutPanel6.RowCount = 5;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.4058F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 61.5942F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1014, 293);
            this.tableLayoutPanel6.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label7.Location = new System.Drawing.Point(418, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 23);
            this.label7.TabIndex = 6;
            this.label7.Text = "Published Date:";
            // 
            // NumberOfCopies_Available
            // 
            this.NumberOfCopies_Available.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.NumberOfCopies_Available.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.NumberOfCopies_Available.Location = new System.Drawing.Point(567, 180);
            this.NumberOfCopies_Available.Name = "NumberOfCopies_Available";
            this.NumberOfCopies_Available.Size = new System.Drawing.Size(232, 26);
            this.NumberOfCopies_Available.TabIndex = 14;
            this.NumberOfCopies_Available.Validating += new System.ComponentModel.CancelEventHandler(this.NumberOfCopies_Available_Validating);
            // 
            // Rent_Price
            // 
            this.Rent_Price.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Rent_Price.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Rent_Price.Location = new System.Drawing.Point(567, 63);
            this.Rent_Price.Name = "Rent_Price";
            this.Rent_Price.Size = new System.Drawing.Size(232, 26);
            this.Rent_Price.TabIndex = 11;
            this.Rent_Price.Validating += new System.ComponentModel.CancelEventHandler(this.Rent_Price_Validating);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label11.Location = new System.Drawing.Point(425, 64);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(136, 23);
            this.label11.TabIndex = 4;
            this.label11.Text = "Rent Price ($):";
            // 
            // Sell_Price
            // 
            this.Sell_Price.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Sell_Price.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Sell_Price.Location = new System.Drawing.Point(567, 122);
            this.Sell_Price.Name = "Sell_Price";
            this.Sell_Price.Size = new System.Drawing.Size(232, 26);
            this.Sell_Price.TabIndex = 13;
            this.Sell_Price.Validating += new System.ComponentModel.CancelEventHandler(this.Sell_Price_Validating);
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label12.Location = new System.Drawing.Point(435, 123);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 23);
            this.label12.TabIndex = 7;
            this.label12.Text = "Sell Price ($):";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label13.Location = new System.Drawing.Point(451, 170);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(110, 46);
            this.label13.TabIndex = 3;
            this.label13.Text = "Number Of Copies:";
            // 
            // Published_Date
            // 
            this.Published_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Published_Date.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Published_Date.Location = new System.Drawing.Point(567, 8);
            this.Published_Date.Name = "Published_Date";
            this.Published_Date.Size = new System.Drawing.Size(232, 26);
            this.Published_Date.TabIndex = 15;
            this.Published_Date.Validating += new System.ComponentModel.CancelEventHandler(this.Published_Date_Validating);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label9.Location = new System.Drawing.Point(126, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 23);
            this.label9.TabIndex = 1;
            this.label9.Text = "ISBN:";
            // 
            // ISBN
            // 
            this.ISBN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.ISBN.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.ISBN.Location = new System.Drawing.Point(194, 8);
            this.ISBN.Name = "ISBN";
            this.ISBN.Size = new System.Drawing.Size(214, 26);
            this.ISBN.TabIndex = 10;
            this.ISBN.Validating += new System.ComponentModel.CancelEventHandler(this.ISBN_Validating);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label10.Location = new System.Drawing.Point(131, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 23);
            this.label10.TabIndex = 2;
            this.label10.Text = "Title:";
            // 
            // Title
            // 
            this.Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Title.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Title.Location = new System.Drawing.Point(194, 63);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(214, 26);
            this.Title.TabIndex = 12;
            this.Title.Validating += new System.ComponentModel.CancelEventHandler(this.Title_Validating);
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label14.Location = new System.Drawing.Point(117, 123);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 23);
            this.label14.TabIndex = 5;
            this.label14.Text = "Genre:";
            // 
            // Genre
            // 
            this.Genre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Genre.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Genre.Location = new System.Drawing.Point(194, 122);
            this.Genre.Name = "Genre";
            this.Genre.Size = new System.Drawing.Size(214, 26);
            this.Genre.TabIndex = 9;
            this.Genre.Validating += new System.ComponentModel.CancelEventHandler(this.Genre_Validating);
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label17.Location = new System.Drawing.Point(90, 182);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 23);
            this.label17.TabIndex = 18;
            this.label17.Text = "Author Id:";
            // 
            // author_id
            // 
            this.author_id.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.author_id.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.author_id.Location = new System.Drawing.Point(194, 180);
            this.author_id.Name = "author_id";
            this.author_id.Size = new System.Drawing.Size(214, 26);
            this.author_id.TabIndex = 16;
            this.author_id.Validating += new System.ComponentModel.CancelEventHandler(this.author_id_Validating);
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label18.Location = new System.Drawing.Point(71, 248);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(117, 23);
            this.label18.TabIndex = 19;
            this.label18.Text = "Publisher Id:";
            // 
            // publisher_id
            // 
            this.publisher_id.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.publisher_id.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.publisher_id.Location = new System.Drawing.Point(194, 247);
            this.publisher_id.Name = "publisher_id";
            this.publisher_id.Size = new System.Drawing.Size(214, 26);
            this.publisher_id.TabIndex = 17;
            this.publisher_id.Validating += new System.ComponentModel.CancelEventHandler(this.publisher_id_Validating);
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.BackColor = System.Drawing.Color.Transparent;
            this.tabPage2.Controls.Add(this.panel_1);
            this.tabPage2.Location = new System.Drawing.Point(28, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabPage2.Size = new System.Drawing.Size(993, 514);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Get Book (s)";
            // 
            // panel_1
            // 
            this.panel_1.AutoScroll = true;
            this.panel_1.Controls.Add(this.tableLayoutPanel11);
            this.panel_1.Controls.Add(this.dataGridViewB_3);
            this.panel_1.Controls.Add(this.dataGridViewB_4);
            this.panel_1.Controls.Add(this.tableLayoutPanel12);
            this.panel_1.Controls.Add(this.dataGridViewB_2);
            this.panel_1.Controls.Add(this.tableLayoutPanel10);
            this.panel_1.Controls.Add(this.dataGridViewB_1);
            this.panel_1.Controls.Add(this.tableLayoutPanel9);
            this.panel_1.Controls.Add(this.tableLayoutPanel8);
            this.panel_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_1.Location = new System.Drawing.Point(3, 3);
            this.panel_1.Name = "panel_1";
            this.panel_1.Size = new System.Drawing.Size(987, 508);
            this.panel_1.TabIndex = 2;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel11.ColumnCount = 3;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.65475F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.68131F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel11.Controls.Add(this.label23, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.getBookGenreBtn, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.getBook_genre, 1, 0);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(0, 277);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(790, 59);
            this.tableLayoutPanel11.TabIndex = 11;
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label23.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label23.Location = new System.Drawing.Point(24, 6);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(144, 46);
            this.label23.TabIndex = 0;
            this.label23.Text = "Enter the Book Genre:";
            // 
            // getBookGenreBtn
            // 
            this.getBookGenreBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.getBookGenreBtn.BackColor = System.Drawing.Color.LightBlue;
            this.getBookGenreBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.getBookGenreBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getBookGenreBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.getBookGenreBtn.Location = new System.Drawing.Point(392, 17);
            this.getBookGenreBtn.Name = "getBookGenreBtn";
            this.getBookGenreBtn.Size = new System.Drawing.Size(151, 25);
            this.getBookGenreBtn.TabIndex = 2;
            this.getBookGenreBtn.Text = "Submit";
            this.getBookGenreBtn.UseVisualStyleBackColor = false;
            this.getBookGenreBtn.Click += new System.EventHandler(this.getBookGenreBtn_Click);
            // 
            // getBook_genre
            // 
            this.getBook_genre.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.getBook_genre.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.getBook_genre.ForeColor = System.Drawing.Color.Black;
            this.getBook_genre.Location = new System.Drawing.Point(174, 16);
            this.getBook_genre.Name = "getBook_genre";
            this.getBook_genre.Size = new System.Drawing.Size(212, 26);
            this.getBook_genre.TabIndex = 1;
            this.getBook_genre.Validating += new System.ComponentModel.CancelEventHandler(this.getBook_genre_Validating);
            // 
            // dataGridViewB_3
            // 
            this.dataGridViewB_3.AllowUserToAddRows = false;
            this.dataGridViewB_3.AllowUserToDeleteRows = false;
            this.dataGridViewB_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewB_3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewB_3.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridViewB_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewB_3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.dataGridViewB_3.ColumnHeadersHeight = 29;
            this.dataGridViewB_3.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle38.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewB_3.DefaultCellStyle = dataGridViewCellStyle38;
            this.dataGridViewB_3.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridViewB_3.Location = new System.Drawing.Point(0, 342);
            this.dataGridViewB_3.Name = "dataGridViewB_3";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewB_3.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.dataGridViewB_3.RowHeadersWidth = 51;
            this.dataGridViewB_3.Size = new System.Drawing.Size(790, 116);
            this.dataGridViewB_3.TabIndex = 10;
            // 
            // dataGridViewB_4
            // 
            this.dataGridViewB_4.AllowUserToAddRows = false;
            this.dataGridViewB_4.AllowUserToDeleteRows = false;
            dataGridViewCellStyle40.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dataGridViewB_4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle40;
            this.dataGridViewB_4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewB_4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewB_4.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridViewB_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewB_4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle41.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewB_4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle41;
            this.dataGridViewB_4.ColumnHeadersHeight = 29;
            this.dataGridViewB_4.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewB_4.DefaultCellStyle = dataGridViewCellStyle42;
            this.dataGridViewB_4.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridViewB_4.Location = new System.Drawing.Point(0, 529);
            this.dataGridViewB_4.Name = "dataGridViewB_4";
            this.dataGridViewB_4.ReadOnly = true;
            this.dataGridViewB_4.RowHeadersWidth = 51;
            this.dataGridViewB_4.Size = new System.Drawing.Size(790, 222);
            this.dataGridViewB_4.TabIndex = 9;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel12.ColumnCount = 3;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.22472F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.11134F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel12.Controls.Add(this.label24, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.viewBooksBtn, 1, 0);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(0, 464);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(790, 59);
            this.tableLayoutPanel12.TabIndex = 8;
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label24.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label24.Location = new System.Drawing.Point(48, 6);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(108, 46);
            this.label24.TabIndex = 0;
            this.label24.Text = "Get All the Books:";
            // 
            // viewBooksBtn
            // 
            this.viewBooksBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.viewBooksBtn.BackColor = System.Drawing.Color.LightBlue;
            this.viewBooksBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.viewBooksBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.viewBooksBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.viewBooksBtn.Location = new System.Drawing.Point(162, 17);
            this.viewBooksBtn.Name = "viewBooksBtn";
            this.viewBooksBtn.Size = new System.Drawing.Size(151, 25);
            this.viewBooksBtn.TabIndex = 2;
            this.viewBooksBtn.Text = "View All";
            this.viewBooksBtn.UseVisualStyleBackColor = false;
            this.viewBooksBtn.Click += new System.EventHandler(this.viewBooksBtn_Click);
            // 
            // dataGridViewB_2
            // 
            this.dataGridViewB_2.AllowUserToAddRows = false;
            this.dataGridViewB_2.AllowUserToDeleteRows = false;
            this.dataGridViewB_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewB_2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewB_2.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridViewB_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle43.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewB_2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle43;
            this.dataGridViewB_2.ColumnHeadersHeight = 29;
            this.dataGridViewB_2.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle44.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewB_2.DefaultCellStyle = dataGridViewCellStyle44;
            this.dataGridViewB_2.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridViewB_2.Location = new System.Drawing.Point(-3, 214);
            this.dataGridViewB_2.Name = "dataGridViewB_2";
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewB_2.RowHeadersDefaultCellStyle = dataGridViewCellStyle45;
            this.dataGridViewB_2.RowHeadersWidth = 51;
            this.dataGridViewB_2.Size = new System.Drawing.Size(790, 58);
            this.dataGridViewB_2.TabIndex = 6;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel10.ColumnCount = 3;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.16548F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.17058F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel10.Controls.Add(this.label21, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.getBook_title, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.getBookTitleBtn, 2, 0);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(0, 166);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(790, 59);
            this.tableLayoutPanel10.TabIndex = 5;
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label21.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label21.Location = new System.Drawing.Point(28, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(144, 46);
            this.label21.TabIndex = 0;
            this.label21.Text = "Enter the Book Title:";
            // 
            // getBook_title
            // 
            this.getBook_title.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.getBook_title.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.getBook_title.ForeColor = System.Drawing.Color.Black;
            this.getBook_title.Location = new System.Drawing.Point(178, 16);
            this.getBook_title.Name = "getBook_title";
            this.getBook_title.Size = new System.Drawing.Size(208, 26);
            this.getBook_title.TabIndex = 1;
            this.getBook_title.Validating += new System.ComponentModel.CancelEventHandler(this.getBook_title_Validating);
            // 
            // getBookTitleBtn
            // 
            this.getBookTitleBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.getBookTitleBtn.BackColor = System.Drawing.Color.LightBlue;
            this.getBookTitleBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.getBookTitleBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getBookTitleBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.getBookTitleBtn.Location = new System.Drawing.Point(392, 17);
            this.getBookTitleBtn.Name = "getBookTitleBtn";
            this.getBookTitleBtn.Size = new System.Drawing.Size(151, 25);
            this.getBookTitleBtn.TabIndex = 2;
            this.getBookTitleBtn.Text = "Submit";
            this.getBookTitleBtn.UseVisualStyleBackColor = false;
            this.getBookTitleBtn.Click += new System.EventHandler(this.getBookTitleBtn_Click);
            // 
            // dataGridViewB_1
            // 
            this.dataGridViewB_1.AllowUserToAddRows = false;
            this.dataGridViewB_1.AllowUserToDeleteRows = false;
            this.dataGridViewB_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewB_1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewB_1.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridViewB_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle46.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewB_1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle46;
            this.dataGridViewB_1.ColumnHeadersHeight = 29;
            this.dataGridViewB_1.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle47.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewB_1.DefaultCellStyle = dataGridViewCellStyle47;
            this.dataGridViewB_1.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridViewB_1.Location = new System.Drawing.Point(0, 102);
            this.dataGridViewB_1.Name = "dataGridViewB_1";
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle48.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle48.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewB_1.RowHeadersDefaultCellStyle = dataGridViewCellStyle48;
            this.dataGridViewB_1.RowHeadersWidth = 51;
            this.dataGridViewB_1.Size = new System.Drawing.Size(790, 58);
            this.dataGridViewB_1.TabIndex = 4;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel9.ColumnCount = 3;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.65475F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.68131F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel9.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.getBook_id, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.getBookIdBtn, 2, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 54);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(790, 59);
            this.tableLayoutPanel9.TabIndex = 3;
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label22.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label22.Location = new System.Drawing.Point(24, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(144, 46);
            this.label22.TabIndex = 0;
            this.label22.Text = "Enter the Book id:";
            // 
            // getBook_id
            // 
            this.getBook_id.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.getBook_id.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.getBook_id.ForeColor = System.Drawing.Color.Black;
            this.getBook_id.Location = new System.Drawing.Point(174, 16);
            this.getBook_id.Name = "getBook_id";
            this.getBook_id.Size = new System.Drawing.Size(212, 26);
            this.getBook_id.TabIndex = 1;
            this.getBook_id.Validating += new System.ComponentModel.CancelEventHandler(this.getBook_id_Validating);
            // 
            // getBookIdBtn
            // 
            this.getBookIdBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.getBookIdBtn.BackColor = System.Drawing.Color.LightBlue;
            this.getBookIdBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.getBookIdBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getBookIdBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.getBookIdBtn.Location = new System.Drawing.Point(392, 17);
            this.getBookIdBtn.Name = "getBookIdBtn";
            this.getBookIdBtn.Size = new System.Drawing.Size(151, 25);
            this.getBookIdBtn.TabIndex = 2;
            this.getBookIdBtn.Text = "Submit";
            this.getBookIdBtn.UseVisualStyleBackColor = false;
            this.getBookIdBtn.Click += new System.EventHandler(this.getBookIdBtn_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel8.ColumnCount = 4;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 193F));
            this.tableLayoutPanel8.Controls.Add(this.label19, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.label20, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.dateLabel8, 3, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(966, 48);
            this.tableLayoutPanel8.TabIndex = 2;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label19.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label19.Location = new System.Drawing.Point(356, 12);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(119, 23);
            this.label19.TabIndex = 0;
            this.label19.Text = "Get Book (s)";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label20.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label20.Location = new System.Drawing.Point(711, 12);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(58, 23);
            this.label20.TabIndex = 1;
            this.label20.Text = "Date:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel8
            // 
            this.dateLabel8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel8.AutoSize = true;
            this.dateLabel8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel8.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel8.Location = new System.Drawing.Point(775, 12);
            this.dateLabel8.Name = "dateLabel8";
            this.dateLabel8.Size = new System.Drawing.Size(47, 23);
            this.dateLabel8.TabIndex = 2;
            this.dateLabel8.Text = "date";
            this.dateLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage4
            // 
            this.tabPage4.AutoScroll = true;
            this.tabPage4.BackColor = System.Drawing.Color.Transparent;
            this.tabPage4.Controls.Add(this.panel3);
            this.tabPage4.Controls.Add(this.tableLayoutPanel15);
            this.tabPage4.Controls.Add(this.tableLayoutPanel14);
            this.tabPage4.Controls.Add(this.tableLayoutPanel13);
            this.tabPage4.Location = new System.Drawing.Point(28, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(993, 514);
            this.tabPage4.TabIndex = 2;
            this.tabPage4.Text = "Delete Book";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackgroundImage = global::LibraryWinForm.Properties.Resources.books;
            this.panel3.Location = new System.Drawing.Point(3, 186);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(979, 299);
            this.panel3.TabIndex = 8;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel15.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel15.Controls.Add(this.messagelbl2, 0, 0);
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 143);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(985, 37);
            this.tableLayoutPanel15.TabIndex = 7;
            // 
            // messagelbl2
            // 
            this.messagelbl2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.messagelbl2.AutoSize = true;
            this.messagelbl2.BackColor = System.Drawing.Color.LightBlue;
            this.messagelbl2.ForeColor = System.Drawing.Color.Red;
            this.messagelbl2.Location = new System.Drawing.Point(3, 9);
            this.messagelbl2.Name = "messagelbl2";
            this.messagelbl2.Size = new System.Drawing.Size(0, 19);
            this.messagelbl2.TabIndex = 5;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel14.ColumnCount = 3;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.39122F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.14913F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel14.Controls.Add(this.label28, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.delBookId, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.delBookBtn, 2, 0);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 78);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(979, 59);
            this.tableLayoutPanel14.TabIndex = 4;
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label28.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label28.Location = new System.Drawing.Point(59, 18);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(166, 23);
            this.label28.TabIndex = 0;
            this.label28.Text = "Enter the Book id:";
            // 
            // delBookId
            // 
            this.delBookId.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.delBookId.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.delBookId.ForeColor = System.Drawing.Color.Black;
            this.delBookId.Location = new System.Drawing.Point(231, 16);
            this.delBookId.Name = "delBookId";
            this.delBookId.Size = new System.Drawing.Size(241, 26);
            this.delBookId.TabIndex = 1;
            this.delBookId.Validating += new System.ComponentModel.CancelEventHandler(this.delBookId_Validating);
            // 
            // delBookBtn
            // 
            this.delBookBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.delBookBtn.BackColor = System.Drawing.Color.LightBlue;
            this.delBookBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.delBookBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delBookBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.delBookBtn.Location = new System.Drawing.Point(486, 17);
            this.delBookBtn.Name = "delBookBtn";
            this.delBookBtn.Size = new System.Drawing.Size(151, 25);
            this.delBookBtn.TabIndex = 2;
            this.delBookBtn.Text = "Delete Book";
            this.delBookBtn.UseVisualStyleBackColor = false;
            this.delBookBtn.Click += new System.EventHandler(this.delBookBtn_Click);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel13.ColumnCount = 4;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 193F));
            this.tableLayoutPanel13.Controls.Add(this.label25, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.label26, 2, 0);
            this.tableLayoutPanel13.Controls.Add(this.dateLabel9, 3, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(993, 48);
            this.tableLayoutPanel13.TabIndex = 3;
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label25.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label25.Location = new System.Drawing.Point(364, 12);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(132, 23);
            this.label25.TabIndex = 0;
            this.label25.Text = "Delete A Book";
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label26.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label26.Location = new System.Drawing.Point(737, 12);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(58, 23);
            this.label26.TabIndex = 1;
            this.label26.Text = "Date:";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel9
            // 
            this.dateLabel9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel9.AutoSize = true;
            this.dateLabel9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel9.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel9.Location = new System.Drawing.Point(801, 12);
            this.dateLabel9.Name = "dateLabel9";
            this.dateLabel9.Size = new System.Drawing.Size(47, 23);
            this.dateLabel9.TabIndex = 2;
            this.dateLabel9.Text = "date";
            this.dateLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.panel4);
            this.tabPage1.Controls.Add(this.tableLayoutPanel18);
            this.tabPage1.Controls.Add(this.tableLayoutPanel17);
            this.tabPage1.Controls.Add(this.tableLayoutPanel16);
            this.tabPage1.Location = new System.Drawing.Point(28, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(993, 514);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Update Nb of Copies";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackgroundImage = global::LibraryWinForm.Properties.Resources.books;
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel4.Location = new System.Drawing.Point(3, 304);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(949, 299);
            this.panel4.TabIndex = 9;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel18.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel18.Controls.Add(this.messagelbl3, 0, 0);
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 261);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(955, 37);
            this.tableLayoutPanel18.TabIndex = 7;
            // 
            // messagelbl3
            // 
            this.messagelbl3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.messagelbl3.AutoSize = true;
            this.messagelbl3.BackColor = System.Drawing.Color.LightBlue;
            this.messagelbl3.ForeColor = System.Drawing.Color.Red;
            this.messagelbl3.Location = new System.Drawing.Point(3, 9);
            this.messagelbl3.Name = "messagelbl3";
            this.messagelbl3.Size = new System.Drawing.Size(0, 19);
            this.messagelbl3.TabIndex = 5;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel17.ColumnCount = 3;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.22472F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.11134F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel17.Controls.Add(this.label31, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.updateBookId, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.updateBtn, 1, 2);
            this.tableLayoutPanel17.Controls.Add(this.updateNbCopy, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.label30, 0, 1);
            this.tableLayoutPanel17.Location = new System.Drawing.Point(0, 71);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 3;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(949, 184);
            this.tableLayoutPanel17.TabIndex = 5;
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label31.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label31.Location = new System.Drawing.Point(23, 22);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(166, 23);
            this.label31.TabIndex = 0;
            this.label31.Text = "Enter the Book id:";
            // 
            // updateBookId
            // 
            this.updateBookId.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.updateBookId.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.updateBookId.ForeColor = System.Drawing.Color.Black;
            this.updateBookId.Location = new System.Drawing.Point(195, 20);
            this.updateBookId.Name = "updateBookId";
            this.updateBookId.Size = new System.Drawing.Size(241, 26);
            this.updateBookId.TabIndex = 1;
            this.updateBookId.Validating += new System.ComponentModel.CancelEventHandler(this.updateBookId_Validating);
            // 
            // updateBtn
            // 
            this.updateBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.updateBtn.BackColor = System.Drawing.Color.LightBlue;
            this.updateBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.updateBtn.Location = new System.Drawing.Point(195, 137);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(151, 32);
            this.updateBtn.TabIndex = 2;
            this.updateBtn.Text = "Update";
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // updateNbCopy
            // 
            this.updateNbCopy.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.updateNbCopy.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.updateNbCopy.ForeColor = System.Drawing.Color.Black;
            this.updateNbCopy.Location = new System.Drawing.Point(195, 82);
            this.updateNbCopy.Name = "updateNbCopy";
            this.updateNbCopy.Size = new System.Drawing.Size(241, 26);
            this.updateNbCopy.TabIndex = 3;
            this.updateNbCopy.Validating += new System.ComponentModel.CancelEventHandler(this.updateNbCopy_Validating);
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label30.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label30.Location = new System.Drawing.Point(32, 72);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(157, 46);
            this.label30.TabIndex = 4;
            this.label30.Text = "Enter Number of Copies:";
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel16.ColumnCount = 4;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 194F));
            this.tableLayoutPanel16.Controls.Add(this.label27, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.label29, 2, 0);
            this.tableLayoutPanel16.Controls.Add(this.dateLabel10, 3, 0);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(987, 48);
            this.tableLayoutPanel16.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label27.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label27.Location = new System.Drawing.Point(312, 12);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(227, 23);
            this.label27.TabIndex = 0;
            this.label27.Text = "Update Number of Copies";
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label29.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label29.Location = new System.Drawing.Point(730, 12);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(58, 23);
            this.label29.TabIndex = 1;
            this.label29.Text = "Date:";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel10
            // 
            this.dateLabel10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel10.AutoSize = true;
            this.dateLabel10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel10.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel10.Location = new System.Drawing.Point(794, 12);
            this.dateLabel10.Name = "dateLabel10";
            this.dateLabel10.Size = new System.Drawing.Size(47, 23);
            this.dateLabel10.TabIndex = 2;
            this.dateLabel10.Text = "date";
            this.dateLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // transactionTab3
            // 
            this.transactionTab3.BackColor = System.Drawing.Color.White;
            this.transactionTab3.Controls.Add(this.tabControl2);
            this.transactionTab3.Location = new System.Drawing.Point(4, 36);
            this.transactionTab3.Name = "transactionTab3";
            this.transactionTab3.Size = new System.Drawing.Size(1031, 528);
            this.transactionTab3.TabIndex = 0;
            this.transactionTab3.Text = "Transactions";
            // 
            // tabControl2
            // 
            this.tabControl2.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage9);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Multiline = true;
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1031, 528);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage6
            // 
            this.tabPage6.AutoScroll = true;
            this.tabPage6.BackColor = System.Drawing.Color.Transparent;
            this.tabPage6.Controls.Add(this.tableLayoutPanel27);
            this.tabPage6.Controls.Add(this.label38);
            this.tabPage6.Controls.Add(this.checkBtn);
            this.tabPage6.Controls.Add(this.Submit_Rent);
            this.tabPage6.Controls.Add(this.tableLayoutPanel19);
            this.tabPage6.Controls.Add(this.tableLayoutPanel20);
            this.tabPage6.Location = new System.Drawing.Point(28, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(999, 520);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Rent Book";
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel27.ColumnCount = 2;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.Controls.Add(this.messagelbl6, 0, 1);
            this.tableLayoutPanel27.Controls.Add(this.messagelbl5, 1, 0);
            this.tableLayoutPanel27.Controls.Add(this.messagelbl4, 0, 0);
            this.tableLayoutPanel27.Location = new System.Drawing.Point(6, 453);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 2;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(987, 63);
            this.tableLayoutPanel27.TabIndex = 7;
            // 
            // messagelbl6
            // 
            this.messagelbl6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.messagelbl6.AutoSize = true;
            this.messagelbl6.BackColor = System.Drawing.Color.LightBlue;
            this.messagelbl6.ForeColor = System.Drawing.Color.Red;
            this.messagelbl6.Location = new System.Drawing.Point(3, 40);
            this.messagelbl6.Name = "messagelbl6";
            this.messagelbl6.Size = new System.Drawing.Size(487, 19);
            this.messagelbl6.TabIndex = 10;
            // 
            // messagelbl5
            // 
            this.messagelbl5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.messagelbl5.AutoSize = true;
            this.messagelbl5.BackColor = System.Drawing.Color.LightBlue;
            this.messagelbl5.ForeColor = System.Drawing.Color.Red;
            this.messagelbl5.Location = new System.Drawing.Point(496, 9);
            this.messagelbl5.Name = "messagelbl5";
            this.messagelbl5.Size = new System.Drawing.Size(488, 19);
            this.messagelbl5.TabIndex = 9;
            // 
            // messagelbl4
            // 
            this.messagelbl4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.messagelbl4.AutoSize = true;
            this.messagelbl4.BackColor = System.Drawing.Color.LightBlue;
            this.messagelbl4.ForeColor = System.Drawing.Color.Red;
            this.messagelbl4.Location = new System.Drawing.Point(3, 9);
            this.messagelbl4.Name = "messagelbl4";
            this.messagelbl4.Size = new System.Drawing.Size(487, 19);
            this.messagelbl4.TabIndex = 8;
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.LightBlue;
            this.label38.ForeColor = System.Drawing.Color.Red;
            this.label38.Location = new System.Drawing.Point(78, 431);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(0, 19);
            this.label38.TabIndex = 6;
            // 
            // checkBtn
            // 
            this.checkBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkBtn.BackColor = System.Drawing.Color.LightBlue;
            this.checkBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.checkBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.checkBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.checkBtn.Location = new System.Drawing.Point(182, 404);
            this.checkBtn.Name = "checkBtn";
            this.checkBtn.Size = new System.Drawing.Size(185, 41);
            this.checkBtn.TabIndex = 3;
            this.checkBtn.Text = "Check Availability";
            this.checkBtn.UseVisualStyleBackColor = false;
            this.checkBtn.Click += new System.EventHandler(this.checkBtn_Click);
            // 
            // Submit_Rent
            // 
            this.Submit_Rent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Submit_Rent.BackColor = System.Drawing.Color.LightBlue;
            this.Submit_Rent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Submit_Rent.Enabled = false;
            this.Submit_Rent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Submit_Rent.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.Submit_Rent.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Submit_Rent.Location = new System.Drawing.Point(562, 404);
            this.Submit_Rent.Name = "Submit_Rent";
            this.Submit_Rent.Size = new System.Drawing.Size(185, 41);
            this.Submit_Rent.TabIndex = 2;
            this.Submit_Rent.Text = "Submit";
            this.Submit_Rent.UseVisualStyleBackColor = false;
            this.Submit_Rent.Click += new System.EventHandler(this.Submit_Rent_Click);
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel19.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel19.ColumnCount = 5;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.031F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.9021F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.26269F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.68657F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.11764F));
            this.tableLayoutPanel19.Controls.Add(this.Rent_Start_Date, 1, 2);
            this.tableLayoutPanel19.Controls.Add(this.label35, 0, 2);
            this.tableLayoutPanel19.Controls.Add(this.label32, 2, 1);
            this.tableLayoutPanel19.Controls.Add(this.Rent_Customer_id, 3, 1);
            this.tableLayoutPanel19.Controls.Add(this.label37, 2, 2);
            this.tableLayoutPanel19.Controls.Add(this.Rent_End_Date, 3, 2);
            this.tableLayoutPanel19.Controls.Add(this.label34, 0, 1);
            this.tableLayoutPanel19.Controls.Add(this.Rent_Book_id, 1, 1);
            this.tableLayoutPanel19.Controls.Add(this.Rent_E_username, 2, 0);
            this.tableLayoutPanel19.Controls.Add(this.label36, 1, 0);
            this.tableLayoutPanel19.Location = new System.Drawing.Point(0, 133);
            this.tableLayoutPanel19.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.Padding = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.tableLayoutPanel19.RowCount = 3;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(996, 241);
            this.tableLayoutPanel19.TabIndex = 1;
            // 
            // Rent_Start_Date
            // 
            this.Rent_Start_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Rent_Start_Date.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Rent_Start_Date.Location = new System.Drawing.Point(191, 196);
            this.Rent_Start_Date.Name = "Rent_Start_Date";
            this.Rent_Start_Date.Size = new System.Drawing.Size(210, 26);
            this.Rent_Start_Date.TabIndex = 12;
            this.Rent_Start_Date.Validating += new System.ComponentModel.CancelEventHandler(this.Rent_Start_Date_Validating);
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label35.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label35.Location = new System.Drawing.Point(33, 198);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(152, 23);
            this.label35.TabIndex = 2;
            this.label35.Text = "Rent Start Date:";
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label32.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label32.Location = new System.Drawing.Point(432, 122);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(119, 23);
            this.label32.TabIndex = 6;
            this.label32.Text = "Customer id:";
            // 
            // Rent_Customer_id
            // 
            this.Rent_Customer_id.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Rent_Customer_id.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Rent_Customer_id.Location = new System.Drawing.Point(557, 120);
            this.Rent_Customer_id.Name = "Rent_Customer_id";
            this.Rent_Customer_id.Size = new System.Drawing.Size(228, 26);
            this.Rent_Customer_id.TabIndex = 15;
            this.Rent_Customer_id.Validating += new System.ComponentModel.CancelEventHandler(this.Rent_Customer_id_Validating);
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label37.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label37.Location = new System.Drawing.Point(409, 198);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(142, 23);
            this.label37.TabIndex = 7;
            this.label37.Text = "Rent End Date:";
            // 
            // Rent_End_Date
            // 
            this.Rent_End_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Rent_End_Date.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Rent_End_Date.Location = new System.Drawing.Point(557, 196);
            this.Rent_End_Date.Name = "Rent_End_Date";
            this.Rent_End_Date.Size = new System.Drawing.Size(228, 26);
            this.Rent_End_Date.TabIndex = 13;
            this.Rent_End_Date.Validating += new System.ComponentModel.CancelEventHandler(this.Rent_End_Date_Validating);
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label34.Location = new System.Drawing.Point(104, 122);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(81, 23);
            this.label34.TabIndex = 1;
            this.label34.Text = "Book id:";
            // 
            // Rent_Book_id
            // 
            this.Rent_Book_id.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Rent_Book_id.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Rent_Book_id.Location = new System.Drawing.Point(191, 120);
            this.Rent_Book_id.Name = "Rent_Book_id";
            this.Rent_Book_id.Size = new System.Drawing.Size(210, 26);
            this.Rent_Book_id.TabIndex = 10;
            this.Rent_Book_id.Validating += new System.ComponentModel.CancelEventHandler(this.Rent_Book_id_Validating);
            // 
            // Rent_E_username
            // 
            this.Rent_E_username.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Rent_E_username.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Rent_E_username.Location = new System.Drawing.Point(407, 31);
            this.Rent_E_username.Name = "Rent_E_username";
            this.Rent_E_username.Size = new System.Drawing.Size(144, 26);
            this.Rent_E_username.TabIndex = 11;
            this.Rent_E_username.Validating += new System.ComponentModel.CancelEventHandler(this.Rent_E_username_Validating);
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label36.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label36.Location = new System.Drawing.Point(215, 33);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(186, 23);
            this.label36.TabIndex = 4;
            this.label36.Text = "Librarian Username:";
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel20.ColumnCount = 4;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 195F));
            this.tableLayoutPanel20.Controls.Add(this.label40, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.label41, 2, 0);
            this.tableLayoutPanel20.Controls.Add(this.dateLabel11, 3, 0);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(993, 48);
            this.tableLayoutPanel20.TabIndex = 0;
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label40.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label40.Location = new System.Drawing.Point(371, 12);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(115, 23);
            this.label40.TabIndex = 0;
            this.label40.Text = "Rent a Book";
            // 
            // label41
            // 
            this.label41.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label41.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label41.Location = new System.Drawing.Point(735, 12);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(58, 23);
            this.label41.TabIndex = 1;
            this.label41.Text = "Date:";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel11
            // 
            this.dateLabel11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel11.AutoSize = true;
            this.dateLabel11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel11.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel11.Location = new System.Drawing.Point(799, 12);
            this.dateLabel11.Name = "dateLabel11";
            this.dateLabel11.Size = new System.Drawing.Size(47, 23);
            this.dateLabel11.TabIndex = 3;
            this.dateLabel11.Text = "date";
            this.dateLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage7
            // 
            this.tabPage7.AutoScroll = true;
            this.tabPage7.BackColor = System.Drawing.Color.Transparent;
            this.tabPage7.Controls.Add(this.panel5);
            this.tabPage7.Controls.Add(this.tableLayoutPanel23);
            this.tabPage7.Location = new System.Drawing.Point(28, 4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabPage7.Size = new System.Drawing.Size(999, 520);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "View Rented Book (s)";
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.dataGridView_R2);
            this.panel5.Controls.Add(this.dataGridView_R1);
            this.panel5.Controls.Add(this.tableLayoutPanel21);
            this.panel5.Controls.Add(this.tableLayoutPanel22);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 51);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(993, 466);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_R2
            // 
            this.dataGridView_R2.AllowUserToAddRows = false;
            this.dataGridView_R2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle49.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dataGridView_R2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle49;
            this.dataGridView_R2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_R2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_R2.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView_R2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView_R2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle50.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle50.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle50.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle50.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle50.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_R2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle50;
            this.dataGridView_R2.ColumnHeadersHeight = 29;
            this.dataGridView_R2.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle51.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle51.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle51.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle51.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle51.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle51.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_R2.DefaultCellStyle = dataGridViewCellStyle51;
            this.dataGridView_R2.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridView_R2.Location = new System.Drawing.Point(-3, 285);
            this.dataGridView_R2.Name = "dataGridView_R2";
            this.dataGridView_R2.ReadOnly = true;
            this.dataGridView_R2.RowHeadersWidth = 51;
            this.dataGridView_R2.Size = new System.Drawing.Size(987, 178);
            this.dataGridView_R2.TabIndex = 2;
            // 
            // dataGridView_R1
            // 
            this.dataGridView_R1.AllowUserToAddRows = false;
            this.dataGridView_R1.AllowUserToDeleteRows = false;
            this.dataGridView_R1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_R1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_R1.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView_R1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle52.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle52.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle52.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle52.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle52.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_R1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle52;
            this.dataGridView_R1.ColumnHeadersHeight = 29;
            this.dataGridView_R1.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle53.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle53.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle53.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle53.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle53.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_R1.DefaultCellStyle = dataGridViewCellStyle53;
            this.dataGridView_R1.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridView_R1.Location = new System.Drawing.Point(0, 99);
            this.dataGridView_R1.Name = "dataGridView_R1";
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle54.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle54.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle54.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_R1.RowHeadersDefaultCellStyle = dataGridViewCellStyle54;
            this.dataGridView_R1.RowHeadersWidth = 51;
            this.dataGridView_R1.Size = new System.Drawing.Size(987, 117);
            this.dataGridView_R1.TabIndex = 0;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel21.ColumnCount = 3;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.35628F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.50319F));
            this.tableLayoutPanel21.Controls.Add(this.label43, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.viewAllRentedBtn, 1, 0);
            this.tableLayoutPanel21.Location = new System.Drawing.Point(3, 222);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(996, 57);
            this.tableLayoutPanel21.TabIndex = 1;
            // 
            // label43
            // 
            this.label43.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label43.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label43.Location = new System.Drawing.Point(9, 17);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(201, 23);
            this.label43.TabIndex = 0;
            this.label43.Text = "Get All Rented Books:";
            // 
            // viewAllRentedBtn
            // 
            this.viewAllRentedBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.viewAllRentedBtn.BackColor = System.Drawing.Color.LightBlue;
            this.viewAllRentedBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.viewAllRentedBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.viewAllRentedBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.viewAllRentedBtn.Location = new System.Drawing.Point(216, 13);
            this.viewAllRentedBtn.Name = "viewAllRentedBtn";
            this.viewAllRentedBtn.Size = new System.Drawing.Size(204, 30);
            this.viewAllRentedBtn.TabIndex = 1;
            this.viewAllRentedBtn.Text = "View All";
            this.viewAllRentedBtn.UseVisualStyleBackColor = false;
            this.viewAllRentedBtn.Click += new System.EventHandler(this.viewAllRentedBtn_Click);
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel22.ColumnCount = 3;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.39122F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.14913F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel22.Controls.Add(this.label44, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.RentCustId, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.getRentedByIdBtn, 2, 0);
            this.tableLayoutPanel22.Location = new System.Drawing.Point(0, 34);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(987, 59);
            this.tableLayoutPanel22.TabIndex = 0;
            // 
            // label44
            // 
            this.label44.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label44.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label44.Location = new System.Drawing.Point(23, 18);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(204, 23);
            this.label44.TabIndex = 0;
            this.label44.Text = "Enter the Customer id:";
            // 
            // RentCustId
            // 
            this.RentCustId.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.RentCustId.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.RentCustId.ForeColor = System.Drawing.Color.Black;
            this.RentCustId.Location = new System.Drawing.Point(233, 16);
            this.RentCustId.Name = "RentCustId";
            this.RentCustId.Size = new System.Drawing.Size(241, 26);
            this.RentCustId.TabIndex = 1;
            this.RentCustId.Validating += new System.ComponentModel.CancelEventHandler(this.RentCustId_Validating);
            // 
            // getRentedByIdBtn
            // 
            this.getRentedByIdBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.getRentedByIdBtn.BackColor = System.Drawing.Color.LightBlue;
            this.getRentedByIdBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.getRentedByIdBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.getRentedByIdBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.getRentedByIdBtn.Location = new System.Drawing.Point(490, 17);
            this.getRentedByIdBtn.Name = "getRentedByIdBtn";
            this.getRentedByIdBtn.Size = new System.Drawing.Size(151, 25);
            this.getRentedByIdBtn.TabIndex = 2;
            this.getRentedByIdBtn.Text = "Submit";
            this.getRentedByIdBtn.UseVisualStyleBackColor = false;
            this.getRentedByIdBtn.Click += new System.EventHandler(this.getRentedByIdBtn_Click);
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel23.ColumnCount = 4;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 195F));
            this.tableLayoutPanel23.Controls.Add(this.label45, 1, 0);
            this.tableLayoutPanel23.Controls.Add(this.label46, 2, 0);
            this.tableLayoutPanel23.Controls.Add(this.dateLabel12, 3, 0);
            this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(993, 48);
            this.tableLayoutPanel23.TabIndex = 1;
            // 
            // label45
            // 
            this.label45.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label45.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label45.Location = new System.Drawing.Point(331, 12);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(194, 23);
            this.label45.TabIndex = 0;
            this.label45.Text = "View Rented Book (s)";
            // 
            // label46
            // 
            this.label46.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label46.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label46.Location = new System.Drawing.Point(735, 12);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(58, 23);
            this.label46.TabIndex = 1;
            this.label46.Text = "Date:";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel12
            // 
            this.dateLabel12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel12.AutoSize = true;
            this.dateLabel12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel12.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel12.Location = new System.Drawing.Point(799, 12);
            this.dateLabel12.Name = "dateLabel12";
            this.dateLabel12.Size = new System.Drawing.Size(47, 23);
            this.dateLabel12.TabIndex = 2;
            this.dateLabel12.Text = "date";
            this.dateLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage8
            // 
            this.tabPage8.AutoScroll = true;
            this.tabPage8.BackColor = System.Drawing.Color.Transparent;
            this.tabPage8.Controls.Add(this.panel6);
            this.tabPage8.Location = new System.Drawing.Point(28, 4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(999, 520);
            this.tabPage8.TabIndex = 2;
            this.tabPage8.Text = "Sell Book";
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.Controls.Add(this.submitSaleBtn);
            this.panel6.Controls.Add(this.check_saleBtn);
            this.panel6.Controls.Add(this.tableLayoutPanel26);
            this.panel6.Controls.Add(this.tableLayoutPanel25);
            this.panel6.Controls.Add(this.tableLayoutPanel24);
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(992, 513);
            this.panel6.TabIndex = 0;
            // 
            // submitSaleBtn
            // 
            this.submitSaleBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.submitSaleBtn.BackColor = System.Drawing.Color.LightBlue;
            this.submitSaleBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.submitSaleBtn.Enabled = false;
            this.submitSaleBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.submitSaleBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.submitSaleBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.submitSaleBtn.Location = new System.Drawing.Point(558, 363);
            this.submitSaleBtn.Name = "submitSaleBtn";
            this.submitSaleBtn.Size = new System.Drawing.Size(185, 41);
            this.submitSaleBtn.TabIndex = 10;
            this.submitSaleBtn.Text = "Submit";
            this.submitSaleBtn.UseVisualStyleBackColor = false;
            this.submitSaleBtn.Click += new System.EventHandler(this.submitSaleBtn_Click);
            // 
            // check_saleBtn
            // 
            this.check_saleBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.check_saleBtn.BackColor = System.Drawing.Color.LightBlue;
            this.check_saleBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.check_saleBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.check_saleBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.check_saleBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.check_saleBtn.Location = new System.Drawing.Point(192, 363);
            this.check_saleBtn.Name = "check_saleBtn";
            this.check_saleBtn.Size = new System.Drawing.Size(185, 41);
            this.check_saleBtn.TabIndex = 9;
            this.check_saleBtn.Text = "Check Availability";
            this.check_saleBtn.UseVisualStyleBackColor = false;
            this.check_saleBtn.Click += new System.EventHandler(this.check_saleBtn_Click);
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.Controls.Add(this.messagelbl9, 0, 1);
            this.tableLayoutPanel26.Controls.Add(this.messagelbl8, 1, 0);
            this.tableLayoutPanel26.Controls.Add(this.messagelbl7, 0, 0);
            this.tableLayoutPanel26.Location = new System.Drawing.Point(3, 447);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 2;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(987, 63);
            this.tableLayoutPanel26.TabIndex = 8;
            // 
            // messagelbl9
            // 
            this.messagelbl9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.messagelbl9.AutoSize = true;
            this.messagelbl9.BackColor = System.Drawing.Color.LightBlue;
            this.messagelbl9.ForeColor = System.Drawing.Color.Red;
            this.messagelbl9.Location = new System.Drawing.Point(3, 40);
            this.messagelbl9.Name = "messagelbl9";
            this.messagelbl9.Size = new System.Drawing.Size(487, 19);
            this.messagelbl9.TabIndex = 10;
            // 
            // messagelbl8
            // 
            this.messagelbl8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.messagelbl8.AutoSize = true;
            this.messagelbl8.BackColor = System.Drawing.Color.LightBlue;
            this.messagelbl8.ForeColor = System.Drawing.Color.Red;
            this.messagelbl8.Location = new System.Drawing.Point(496, 9);
            this.messagelbl8.Name = "messagelbl8";
            this.messagelbl8.Size = new System.Drawing.Size(488, 19);
            this.messagelbl8.TabIndex = 9;
            // 
            // messagelbl7
            // 
            this.messagelbl7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.messagelbl7.AutoSize = true;
            this.messagelbl7.BackColor = System.Drawing.Color.LightBlue;
            this.messagelbl7.ForeColor = System.Drawing.Color.Red;
            this.messagelbl7.Location = new System.Drawing.Point(3, 9);
            this.messagelbl7.Name = "messagelbl7";
            this.messagelbl7.Size = new System.Drawing.Size(487, 19);
            this.messagelbl7.TabIndex = 8;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel25.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel25.ColumnCount = 5;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.031F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.9021F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.26269F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.68657F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.11764F));
            this.tableLayoutPanel25.Controls.Add(this.label48, 2, 0);
            this.tableLayoutPanel25.Controls.Add(this.Sell_E_username, 3, 1);
            this.tableLayoutPanel25.Controls.Add(this.Sell_Date, 1, 1);
            this.tableLayoutPanel25.Controls.Add(this.label49, 0, 1);
            this.tableLayoutPanel25.Controls.Add(this.label52, 2, 1);
            this.tableLayoutPanel25.Controls.Add(this.Sell_Book_id, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.Sell_Customer_id, 3, 0);
            this.tableLayoutPanel25.Controls.Add(this.label50, 0, 0);
            this.tableLayoutPanel25.Location = new System.Drawing.Point(1, 100);
            this.tableLayoutPanel25.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.Padding = new System.Windows.Forms.Padding(0, 0, 8, 0);
            this.tableLayoutPanel25.RowCount = 2;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(996, 241);
            this.tableLayoutPanel25.TabIndex = 2;
            // 
            // label48
            // 
            this.label48.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label48.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label48.Location = new System.Drawing.Point(432, 48);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(119, 23);
            this.label48.TabIndex = 6;
            this.label48.Text = "Customer id:";
            // 
            // Sell_E_username
            // 
            this.Sell_E_username.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Sell_E_username.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Sell_E_username.Location = new System.Drawing.Point(557, 167);
            this.Sell_E_username.Name = "Sell_E_username";
            this.Sell_E_username.Size = new System.Drawing.Size(228, 26);
            this.Sell_E_username.TabIndex = 11;
            this.Sell_E_username.Validating += new System.ComponentModel.CancelEventHandler(this.Sell_E_username_Validating);
            // 
            // Sell_Date
            // 
            this.Sell_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Sell_Date.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Sell_Date.Location = new System.Drawing.Point(191, 167);
            this.Sell_Date.Name = "Sell_Date";
            this.Sell_Date.Size = new System.Drawing.Size(210, 26);
            this.Sell_Date.TabIndex = 10;
            this.Sell_Date.Validating += new System.ComponentModel.CancelEventHandler(this.Sell_Date_Validating);
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label49.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label49.Location = new System.Drawing.Point(86, 169);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(99, 23);
            this.label49.TabIndex = 0;
            this.label49.Text = "Sale Date:";
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label52.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label52.Location = new System.Drawing.Point(449, 157);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(102, 46);
            this.label52.TabIndex = 4;
            this.label52.Text = "Librarian Username:";
            // 
            // Sell_Book_id
            // 
            this.Sell_Book_id.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Sell_Book_id.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Sell_Book_id.Location = new System.Drawing.Point(191, 47);
            this.Sell_Book_id.Name = "Sell_Book_id";
            this.Sell_Book_id.Size = new System.Drawing.Size(210, 26);
            this.Sell_Book_id.TabIndex = 8;
            this.Sell_Book_id.Validating += new System.ComponentModel.CancelEventHandler(this.Sell_Book_id_Validating);
            // 
            // Sell_Customer_id
            // 
            this.Sell_Customer_id.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Sell_Customer_id.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.Sell_Customer_id.Location = new System.Drawing.Point(557, 47);
            this.Sell_Customer_id.Name = "Sell_Customer_id";
            this.Sell_Customer_id.Size = new System.Drawing.Size(228, 26);
            this.Sell_Customer_id.TabIndex = 15;
            this.Sell_Customer_id.Validating += new System.ComponentModel.CancelEventHandler(this.Sell_Customer_id_Validating);
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label50.Location = new System.Drawing.Point(104, 48);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(81, 23);
            this.label50.TabIndex = 1;
            this.label50.Text = "Book id:";
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel24.ColumnCount = 4;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 194F));
            this.tableLayoutPanel24.Controls.Add(this.label39, 1, 0);
            this.tableLayoutPanel24.Controls.Add(this.label42, 2, 0);
            this.tableLayoutPanel24.Controls.Add(this.dateLabel13, 3, 0);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(992, 48);
            this.tableLayoutPanel24.TabIndex = 1;
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label39.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label39.Location = new System.Drawing.Point(376, 12);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(105, 23);
            this.label39.TabIndex = 0;
            this.label39.Text = "Sell a Book";
            // 
            // label42
            // 
            this.label42.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label42.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label42.Location = new System.Drawing.Point(735, 12);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(58, 23);
            this.label42.TabIndex = 1;
            this.label42.Text = "Date:";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel13
            // 
            this.dateLabel13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel13.AutoSize = true;
            this.dateLabel13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel13.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel13.Location = new System.Drawing.Point(799, 12);
            this.dateLabel13.Name = "dateLabel13";
            this.dateLabel13.Size = new System.Drawing.Size(47, 23);
            this.dateLabel13.TabIndex = 3;
            this.dateLabel13.Text = "date";
            this.dateLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.panel7);
            this.tabPage9.Location = new System.Drawing.Point(28, 4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(999, 520);
            this.tabPage9.TabIndex = 3;
            this.tabPage9.Text = "View Sold Book (s)";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.Controls.Add(this.dataGridView_S2);
            this.panel7.Controls.Add(this.tableLayoutPanel30);
            this.panel7.Controls.Add(this.dataGridView_S1);
            this.panel7.Controls.Add(this.tableLayoutPanel29);
            this.panel7.Controls.Add(this.tableLayoutPanel28);
            this.panel7.Location = new System.Drawing.Point(0, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(995, 514);
            this.panel7.TabIndex = 0;
            // 
            // dataGridView_S2
            // 
            this.dataGridView_S2.AllowUserToAddRows = false;
            this.dataGridView_S2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle55.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dataGridView_S2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle55;
            this.dataGridView_S2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_S2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_S2.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView_S2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView_S2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle56.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle56.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle56.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle56.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle56.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_S2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle56;
            this.dataGridView_S2.ColumnHeadersHeight = 29;
            this.dataGridView_S2.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle57.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle57.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle57.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle57.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_S2.DefaultCellStyle = dataGridViewCellStyle57;
            this.dataGridView_S2.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridView_S2.Location = new System.Drawing.Point(8, 333);
            this.dataGridView_S2.Name = "dataGridView_S2";
            this.dataGridView_S2.ReadOnly = true;
            this.dataGridView_S2.RowHeadersWidth = 51;
            this.dataGridView_S2.Size = new System.Drawing.Size(987, 178);
            this.dataGridView_S2.TabIndex = 6;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel30.ColumnCount = 3;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.35628F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 53.50319F));
            this.tableLayoutPanel30.Controls.Add(this.label55, 0, 0);
            this.tableLayoutPanel30.Controls.Add(this.viewSoldBtn, 1, 0);
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 273);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 1;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(996, 57);
            this.tableLayoutPanel30.TabIndex = 5;
            // 
            // label55
            // 
            this.label55.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label55.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label55.Location = new System.Drawing.Point(34, 17);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(176, 23);
            this.label55.TabIndex = 0;
            this.label55.Text = "Get All Sold Books:";
            // 
            // viewSoldBtn
            // 
            this.viewSoldBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.viewSoldBtn.BackColor = System.Drawing.Color.LightBlue;
            this.viewSoldBtn.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.viewSoldBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.viewSoldBtn.ForeColor = System.Drawing.Color.MidnightBlue;
            this.viewSoldBtn.Location = new System.Drawing.Point(216, 13);
            this.viewSoldBtn.Name = "viewSoldBtn";
            this.viewSoldBtn.Size = new System.Drawing.Size(204, 30);
            this.viewSoldBtn.TabIndex = 1;
            this.viewSoldBtn.Text = "View All";
            this.viewSoldBtn.UseVisualStyleBackColor = false;
            this.viewSoldBtn.Click += new System.EventHandler(this.viewSoldBtn_Click);
            // 
            // dataGridView_S1
            // 
            this.dataGridView_S1.AllowUserToAddRows = false;
            this.dataGridView_S1.AllowUserToDeleteRows = false;
            this.dataGridView_S1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_S1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_S1.BackgroundColor = System.Drawing.Color.LightBlue;
            this.dataGridView_S1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle58.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle58.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle58.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle58.SelectionBackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle58.SelectionForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_S1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle58;
            this.dataGridView_S1.ColumnHeadersHeight = 29;
            this.dataGridView_S1.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle59.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle59.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle59.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle59.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle59.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_S1.DefaultCellStyle = dataGridViewCellStyle59;
            this.dataGridView_S1.GridColor = System.Drawing.Color.LightBlue;
            this.dataGridView_S1.Location = new System.Drawing.Point(3, 150);
            this.dataGridView_S1.Name = "dataGridView_S1";
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle60.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle60.Font = new System.Drawing.Font("Times New Roman", 9.9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle60.ForeColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle60.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle60.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_S1.RowHeadersDefaultCellStyle = dataGridViewCellStyle60;
            this.dataGridView_S1.RowHeadersWidth = 51;
            this.dataGridView_S1.Size = new System.Drawing.Size(987, 117);
            this.dataGridView_S1.TabIndex = 4;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel29.ColumnCount = 3;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.39122F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.14913F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5618F));
            this.tableLayoutPanel29.Controls.Add(this.label54, 0, 0);
            this.tableLayoutPanel29.Controls.Add(this.getSellCustId, 1, 0);
            this.tableLayoutPanel29.Controls.Add(this.submit_getSell_custId, 2, 0);
            this.tableLayoutPanel29.Location = new System.Drawing.Point(5, 85);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 1;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(987, 59);
            this.tableLayoutPanel29.TabIndex = 3;
            // 
            // label54
            // 
            this.label54.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label54.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label54.Location = new System.Drawing.Point(23, 18);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(204, 23);
            this.label54.TabIndex = 0;
            this.label54.Text = "Enter the Customer id:";
            // 
            // getSellCustId
            // 
            this.getSellCustId.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.getSellCustId.Font = new System.Drawing.Font("Times New Roman", 9.9F);
            this.getSellCustId.ForeColor = System.Drawing.Color.Black;
            this.getSellCustId.Location = new System.Drawing.Point(233, 16);
            this.getSellCustId.Name = "getSellCustId";
            this.getSellCustId.Size = new System.Drawing.Size(241, 26);
            this.getSellCustId.TabIndex = 1;
            this.getSellCustId.Validating += new System.ComponentModel.CancelEventHandler(this.getSellCustId_Validating);
            // 
            // submit_getSell_custId
            // 
            this.submit_getSell_custId.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.submit_getSell_custId.BackColor = System.Drawing.Color.LightBlue;
            this.submit_getSell_custId.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.submit_getSell_custId.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.submit_getSell_custId.ForeColor = System.Drawing.Color.MidnightBlue;
            this.submit_getSell_custId.Location = new System.Drawing.Point(490, 17);
            this.submit_getSell_custId.Name = "submit_getSell_custId";
            this.submit_getSell_custId.Size = new System.Drawing.Size(151, 25);
            this.submit_getSell_custId.TabIndex = 2;
            this.submit_getSell_custId.Text = "Submit";
            this.submit_getSell_custId.UseVisualStyleBackColor = false;
            this.submit_getSell_custId.Click += new System.EventHandler(this.submit_getSell_custId_Click);
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.BackColor = System.Drawing.Color.LightBlue;
            this.tableLayoutPanel28.ColumnCount = 4;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.91411F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.90184F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.25316F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 195F));
            this.tableLayoutPanel28.Controls.Add(this.label47, 1, 0);
            this.tableLayoutPanel28.Controls.Add(this.label51, 2, 0);
            this.tableLayoutPanel28.Controls.Add(this.dateLabel14, 3, 0);
            this.tableLayoutPanel28.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 1;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(995, 48);
            this.tableLayoutPanel28.TabIndex = 2;
            // 
            // label47
            // 
            this.label47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label47.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label47.Location = new System.Drawing.Point(345, 12);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(169, 23);
            this.label47.TabIndex = 0;
            this.label47.Text = "View Sold Book (s)";
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label51.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label51.Location = new System.Drawing.Point(737, 12);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(58, 23);
            this.label51.TabIndex = 1;
            this.label51.Text = "Date:";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateLabel14
            // 
            this.dateLabel14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.dateLabel14.AutoSize = true;
            this.dateLabel14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.dateLabel14.ForeColor = System.Drawing.Color.MidnightBlue;
            this.dateLabel14.Location = new System.Drawing.Point(801, 12);
            this.dateLabel14.Name = "dateLabel14";
            this.dateLabel14.Size = new System.Drawing.Size(47, 23);
            this.dateLabel14.TabIndex = 2;
            this.dateLabel14.Text = "date";
            this.dateLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage3
            // 
            this.tabPage3.Font = new System.Drawing.Font("Sans Serif Collection", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(0, 0);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(200, 100);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Transaction";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 568);
            this.Controls.Add(this.MainTabControl);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Library Managment System";
            this.MainTabControl.ResumeLayout(false);
            this.customerTab1.ResumeLayout(false);
            this.CustomerTabControl.ResumeLayout(false);
            this.addCustTab1.ResumeLayout(false);
            this.InfoTableLayoutPanel2.ResumeLayout(false);
            this.InfoTableLayoutPanel2.PerformLayout();
            this.AddCustTableLayoutPanel1.ResumeLayout(false);
            this.AddCustTableLayoutPanel1.PerformLayout();
            this.getCustTab2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.getCustTableLayoutPanel1.ResumeLayout(false);
            this.getCustTableLayoutPanel1.PerformLayout();
            this.delCustTab3.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.bookTab2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel_1.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB_4)).EndInit();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB_2)).EndInit();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB_1)).EndInit();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel18.PerformLayout();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel16.PerformLayout();
            this.transactionTab3.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel27.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel19.PerformLayout();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel20.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_R2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_R1)).EndInit();
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel21.PerformLayout();
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel22.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel23.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel26.PerformLayout();
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel25.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel24.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_S2)).EndInit();
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel30.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_S1)).EndInit();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel29.PerformLayout();
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel28.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }









        #endregion

        private TabControl MainTabControl;
        private TabPage customerTab1;
        private TabPage bookTab2;
        private TabPage tabPage3;
        private TabPage transactionTab3;
        private TabControl CustomerTabControl;
        private TabPage addCustTab1;
        private TabPage getCustTab2;
        private TabPage delCustTab3;
        private TableLayoutPanel AddCustTableLayoutPanel1;
        private Label AddCustLabel;
        private Label DateLabel;
        private TableLayoutPanel InfoTableLayoutPanel2;
        private Label FirstName;
        private Label LastName;
        private Label add_ress;
        private Label customerUsername;
        private Label dateOfBirth;
        private TextBox Customer_Username;
        private TextBox Address;
        private TextBox Last_Name;
        private TextBox DOB;
        private TextBox First_Name;
        private Button AddCustBtn;
        private TableLayoutPanel getCustTableLayoutPanel1;
        private Label label1;
        private Label DateLabel3;
        private Label dateLabel4;
        private Panel panel1;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label4;
        private TextBox get_Customer_id;
        private TableLayoutPanel tableLayoutPanel2;
        private Label label5;
        private Button ViewAllBtn;
        private Button submitCustId;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private ErrorProvider errorProvider1;
        private Label datelabel2;
        private TableLayoutPanel tableLayoutPanel3;
        private Label label2;
        private Label label3;
        private Label dateLabel6;
        private TableLayoutPanel tableLayoutPanel4;
        private Label label6;
        private TextBox custId_delete;
        private Button submitBtnDlt;
        private Label messagelbl;
        private TableLayoutPanel tableLayoutPanel5;
        private Panel panel2;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Panel panel_1;
        private TabPage tabPage4;
        private TabPage tabPage5;
        private TableLayoutPanel tableLayoutPanel7;
        private Label label15;
        private Label label16;
        private Label dateLabel7;
        private Button addBookBtn;
        private TableLayoutPanel tableLayoutPanel6;
        private Label label7;
        private TextBox NumberOfCopies_Available;
        private TextBox Title;
        private TextBox Rent_Price;
        private TextBox ISBN;
        private Label label9;
        private Label label10;
        private Label label11;
        private TextBox Sell_Price;
        private Label label12;
        private Label label13;
        private Label label14;
        private TextBox Genre;
        private TextBox Published_Date;
        private Label label18;
        private Label label17;
        private TextBox author_id;
        private TextBox publisher_id;
        private DataGridView dataGridViewB_1;
        private TableLayoutPanel tableLayoutPanel9;
        private Label label22;
        private TextBox getBook_id;
        private Button getBookIdBtn;
        private TableLayoutPanel tableLayoutPanel8;
        private Label label19;
        private Label label20;
        private Label dateLabel8;
        private DataGridView dataGridViewB_2;
        private TableLayoutPanel tableLayoutPanel10;
        private Label label21;
        private TextBox getBook_title;
        private Button getBookTitleBtn;
        private Label label23;
        private TextBox getBook_genre;
        private Button getBookGenreBtn;
        private TableLayoutPanel tableLayoutPanel12;
        private Label label24;
        private Button viewBooksBtn;
        private DataGridView dataGridViewB_4;
        private DataGridView dataGridViewB_3;
        private TableLayoutPanel tableLayoutPanel13;
        private Label label25;
        private Label label26;
        private Label dateLabel9;
        private Panel panel3;
        private TableLayoutPanel tableLayoutPanel15;
        private Label messagelbl2;
        private TableLayoutPanel tableLayoutPanel14;
        private Label label28;
        private TextBox delBookId;
        private Button delBookBtn;
        private TableLayoutPanel tableLayoutPanel17;
        private Label label31;
        private TextBox updateBookId;
        private Button updateBtn;
        private TextBox updateNbCopy;
        private Label label30;
        private TableLayoutPanel tableLayoutPanel16;
        private Label label27;
        private Label label29;
        private Label dateLabel10;
        private TableLayoutPanel tableLayoutPanel18;
        private Label messagelbl3;
        private Panel panel4;
        private TabControl tabControl2;
        private TabPage tabPage6;
        private Button Submit_Rent;
        private TableLayoutPanel tableLayoutPanel19;
        private Label label32;
        private TextBox Rent_Start_Date;
        private TextBox Rent_E_username;
        private TextBox Rent_Book_id;
        private Label label34;
        private Label label35;
        private Label label36;
        private TextBox Rent_End_Date;
        private Label label37;
        private TextBox Rent_Customer_id;
        private TableLayoutPanel tableLayoutPanel20;
        private Label label40;
        private Label label41;
        private Label dateLabel11;
        private TabPage tabPage7;
        private Panel panel5;
        private DataGridView dataGridView_R2;
        private DataGridView dataGridView_R1;
        private TableLayoutPanel tableLayoutPanel21;
        private Label label43;
        private Button viewAllRentedBtn;
        private TableLayoutPanel tableLayoutPanel22;
        private Label label44;
        private TextBox RentCustId;
        private Button getRentedByIdBtn;
        private TableLayoutPanel tableLayoutPanel23;
        private Label label45;
        private Label label46;
        private Label dateLabel12;
        private TextBox Email;
        private Label e_mail;
        private Label PhoneNb;
        private TextBox PhoneNumber;
        private TabPage tabPage9;
        private Button checkBtn;
        private Label label38;
        private TableLayoutPanel tableLayoutPanel27;
        private Label messagelbl4;
        private Label messagelbl5;
        private Label messagelbl6;
        private TabPage tabPage8;
        private Panel panel6;
        private TableLayoutPanel tableLayoutPanel26;
        private Label messagelbl9;
        private Label messagelbl8;
        private Label messagelbl7;
        private TableLayoutPanel tableLayoutPanel25;
        private Label label48;
        private TextBox Sell_E_username;
        private TextBox Sell_Date;
        private Label label49;
        private Label label50;
        private Label label52;
        private TextBox Sell_Book_id;
        private TextBox Sell_Customer_id;
        private TableLayoutPanel tableLayoutPanel24;
        private Label label39;
        private Label label42;
        private Label dateLabel13;
        private Button check_saleBtn;
        private Button submitSaleBtn;
        private Panel panel7;
        private DataGridView dataGridView_S2;
        private TableLayoutPanel tableLayoutPanel30;
        private Label label55;
        private Button viewSoldBtn;
        private DataGridView dataGridView_S1;
        private TableLayoutPanel tableLayoutPanel29;
        private Label label54;
        private TextBox getSellCustId;
        private Button submit_getSell_custId;
        private TableLayoutPanel tableLayoutPanel28;
        private Label label47;
        private Label label51;
        private Label dateLabel14;
        private TableLayoutPanel tableLayoutPanel11;
    }
}

