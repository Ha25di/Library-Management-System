﻿using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.DataAccess
{
    public interface IAuthentication_Repository
    {
        Task<IEnumerable<Authentication_System>> getAllUsernamesAsync();

        Task AddUsername(Authentication_System authentication_System);

        Task<bool> CheckUserAsync(string username, string password);
    }
}
