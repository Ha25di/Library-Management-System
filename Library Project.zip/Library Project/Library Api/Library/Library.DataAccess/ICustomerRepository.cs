﻿using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.DataAccess
{
    public interface ICustomerRepository
    {
        Task<IEnumerable<Customer>> getAllCustomersAsync();

        Task<Customer> GetCustomerByIdAsync(int id);

        Task AddCustomer(Customer customer);

        Task DeleteCustomer(int id);
    }
}
