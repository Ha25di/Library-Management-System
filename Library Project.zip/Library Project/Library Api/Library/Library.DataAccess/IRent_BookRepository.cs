﻿using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.DataAccess
{
    public interface IRent_BookRepository
    {
        Task<IEnumerable<Rent_Book>> getAllRentedBooksAsync();

        Task AddRentedBook(Rent_Book rentBook);

        Task<IEnumerable<Rent_Book>> getRentedBookByCustIdAsync(int cust_id);
    }
}
