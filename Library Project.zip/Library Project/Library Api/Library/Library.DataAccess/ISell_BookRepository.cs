﻿using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.DataAccess
{
    public interface ISell_BookRepository
    {
        Task<IEnumerable<Sell_Book>> getAllSoldBooksAsync();

        Task AddSoldBook(Sell_Book soldBook);

        Task<IEnumerable<Sell_Book>> getSoldBookByCustIdAsync(int cust_id);
    }
}
