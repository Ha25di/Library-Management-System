﻿using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.DataAccess
{
    public interface IBookRepository
    {
        Task<IEnumerable<Book>> getAllBooksAsync();

        Task<Book> GetBookByIdAsync(int id);

        Task<Book> GetBookByTitleAsync(string title);

        Task<IEnumerable<Book>> GetBookByGenreAsync(string genre);

        Task AddBook (Book book);

        Task UpdateNumOfCopies (int id, int NumOfCopies);

        Task DeleteBook (int id);

        Task<int> GetNbAvailableByIdAsync (int _id);

        Task DecreaseQty (int id);

        Task <decimal> GetRentPriceAsync (int id);

        Task<decimal> GetSellPriceAsync(int id);

        Task updateCopiesAfterRent();




    }
}
