﻿using Dapper;
using Library.Domain;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.DataAccess
{
   public class BookRepository : IBookRepository
    {
        protected readonly IConfiguration _config;

        public BookRepository(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("LibraryDbConnection"));
            }
        }

        public async Task AddBook(Book book)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"INSERT INTO BOOK (ISBN, Title, Genre, Published_Date, 
                                   Rent_Price, Sell_Price, Book_Author_id, Book_Publisher_id,
                                   NumberOfCopies_Available) VALUES (@ISBN, @Title, @Genre, @Published_Date, 
                                   @Rent_Price, @Sell_Price, @Book_Author_id, @Book_Publisher_id,
                                   @NumberOfCopies_Available)";
                    await DbConnection.ExecuteAsync(query,book);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteBook(int id)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"DELETE FROM BOOK WHERE Book_id = @id";
               
                    await DbConnection.ExecuteAsync(query, new {id = id});
                }
            }
            
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<IEnumerable<Book>> getAllBooksAsync()
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM BOOK";
                    return await DbConnection.QueryAsync<Book>(query);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Book> GetBookByIdAsync(int id)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM BOOK WHERE Book_id = @id";
                    return await DbConnection.QueryFirstOrDefaultAsync<Book>(query, new {id = id});
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public async Task UpdateNumOfCopies (int id, int NumOfCopies)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"UPDATE BOOK
                                     SET NumberOfCopies_Available = @NumOfCopies
                                     WHERE Book_id = @id";
                    await DbConnection.ExecuteAsync(query, new { id, NumOfCopies });
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<Book> GetBookByTitleAsync(string title)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM BOOK WHERE Title = @title";
                    return await DbConnection.QueryFirstOrDefaultAsync<Book>(query, new { title = title });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Book>> GetBookByGenreAsync(string genre)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM BOOK WHERE Genre = @genre";
                    return await DbConnection.QueryAsync<Book>(query, new { genre = genre });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> GetNbAvailableByIdAsync(int Id)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT NumberOfCopies_Available FROM BOOK WHERE Book_id = @Id";
                    return await DbConnection.QueryFirstOrDefaultAsync<int>(query, new { Id = Id });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DecreaseQty(int id)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"UPDATE BOOK 
                                     SET NumberOfCopies_Available = NumberOfCopies_Available - 1
                                     WHERE Book_id = @id";
                    await DbConnection.ExecuteAsync(query, new { id});
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<decimal> GetRentPriceAsync(int id)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT Rent_Price FROM BOOK WHERE Book_id = @Id";
                    return await DbConnection.QueryFirstOrDefaultAsync<decimal>(query, new { id = id });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task updateCopiesAfterRent()
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();

                    
                    using (var transaction = DbConnection.BeginTransaction())
                    {
                        try
                        {
                            
                            string updateQuery = @"
                        UPDATE B
                        SET B.NumberOfCopies_Available = B.NumberOfCopies_Available + ISNULL(R.BooksCount, 0)
                        FROM BOOK B
                        LEFT JOIN (
                            SELECT BookId, COUNT(*) AS BooksCount
                            FROM RENT_BOOK
                            WHERE Rent_End_Date < GETDATE()
                            GROUP BY BookId
                        ) R ON B.book_id = R.BookId;";

                            
                            await DbConnection.ExecuteAsync(updateQuery, transaction: transaction);

                            
                            string deleteQuery = @"
                        DELETE FROM Rent_Book
                        WHERE Rent_End_Date < GETDATE();";

                           
                            await DbConnection.ExecuteAsync(deleteQuery, transaction: transaction);

                            
                            transaction.Commit();
                        }
                        catch (Exception)
                        {
                           
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<decimal> GetSellPriceAsync(int id)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT Sell_Price FROM BOOK WHERE Book_id = @Id";
                    return await DbConnection.QueryFirstOrDefaultAsync<decimal>(query, new { id = id });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}


