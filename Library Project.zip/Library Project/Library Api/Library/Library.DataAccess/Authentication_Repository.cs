﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Library.Domain;
using Dapper;

namespace Library.DataAccess
{
    public class Authentication_Repository : IAuthentication_Repository
    {
        protected readonly IConfiguration _config;

        public Authentication_Repository (IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("LibraryDbConnection"));
            }
        }

        public async Task AddUsername(Authentication_System authentication_System)
        {
            try
            {
                authentication_System.Password = BCrypt.Net.BCrypt.HashPassword(authentication_System.Password);

                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"INSERT INTO Authentication_System (Username, Password)
                                     VALUES (@Username, @Password);";
                    await DbConnection.ExecuteAsync(query, authentication_System);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> CheckUserAsync(string username, string password)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT Password FROM Authentication_System WHERE Username = @username";
                    string storedPasswordHash = await DbConnection.ExecuteScalarAsync<string>(query, new { Username = username });

                    if (storedPasswordHash == null)
                    {
                        return false; // User not found
                    }

                 
                    bool isValid = BCrypt.Net.BCrypt.Verify(password, storedPasswordHash);

                   
                    if (isValid)
                    {
                        return true; 
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                throw; 
            }
        }



    public async Task<IEnumerable<Authentication_System>> getAllUsernamesAsync()
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM Authentication_System";
                    return await DbConnection.QueryAsync<Authentication_System>(query);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

}
