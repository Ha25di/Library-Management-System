﻿using Dapper;
using Library.Domain;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Library.DataAccess
{
    public class Sell_BookRepository : ISell_BookRepository

    {
        protected readonly IConfiguration _config;

        public Sell_BookRepository(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("LibraryDbConnection"));
            }
        }

        public async Task AddSoldBook(Sell_Book sellBook)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"INSERT INTO Sale_Book (BookId, Customer_id_Sell, 
                                                         E_username_Sell, saleDate) 
                                     VALUES (@BookId, @Customer_id_Sell, @E_username_Sell,
                                 @saleDate)";
                    await DbConnection.ExecuteAsync(query, sellBook);


                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<IEnumerable<Sell_Book>> getAllSoldBooksAsync()
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM Sale_Book";
                    return await DbConnection.QueryAsync<Sell_Book>(query);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Sell_Book>> getSoldBookByCustIdAsync(int cust_id)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM Sale_Book WHERE Customer_id_Sell = @cust_id";
                    return await DbConnection.QueryAsync<Sell_Book>(query, new { cust_id = cust_id });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }



    }
}
