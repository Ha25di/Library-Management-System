﻿using Library.Domain;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace Library.DataAccess
{
    public class CustomerRepository : ICustomerRepository
    {
        protected readonly IConfiguration _config;

        public CustomerRepository(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("LibraryDbConnection"));
            }
        }
        public async Task AddCustomer(Customer customer)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"INSERT INTO Customer (First_name, Last_name, 
                                     Email, PhoneNumber,DOB, Address, Customer_Username)
                                     VALUES (@First_name, @Last_name, @Email, @PhoneNumber,
                                     @DOB, @Address, @Customer_Username);";

                    await DbConnection.ExecuteAsync(query, customer);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteCustomer(int id)
        {
            try
            {

                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                     string query = @"DELETE FROM Customer WHERE Customer_id = @id";
                     DbConnection.Execute(query, new { id = id });

                                   
                    await DbConnection.ExecuteAsync(query, new { id = id });
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            

        }

        public async Task<IEnumerable<Customer>> getAllCustomersAsync()
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM Customer";
                    return await DbConnection.QueryAsync<Customer>(query);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Customer> GetCustomerByIdAsync(int id)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM Customer WHERE Customer_id = @id";
                    return await DbConnection.QueryFirstOrDefaultAsync<Customer>(query, new { id = id });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
