﻿using Dapper;
using Library.Domain;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.DataAccess
{
    public class Rent_BookRepository : IRent_BookRepository

    {
        protected readonly IConfiguration _config;

        public Rent_BookRepository(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("LibraryDbConnection"));
            }
        }

        public async Task AddRentedBook(Rent_Book rentBook)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"INSERT INTO Rent_Book (BookId, Customer_id_Rent, 
                                                         E_username_Rent, Rent_Start_Date, Rent_End_Date) 
                                     VALUES (@BookId, @Customer_id_Rent, @E_username_Rent,
                                 @Rent_Start_Date, @Rent_End_Date)";
                    await DbConnection.ExecuteAsync(query, rentBook);
                   

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Rent_Book>> getAllRentedBooksAsync()
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM Rent_Book";
                    return await DbConnection.QueryAsync<Rent_Book>(query);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Rent_Book>> getRentedBookByCustIdAsync(int cust_id)
        {
            try
            {
                using (IDbConnection DbConnection = Connection)
                {
                    DbConnection.Open();
                    string query = @"SELECT * FROM Rent_Book WHERE Customer_id_Rent = @cust_id";
                    return await DbConnection.QueryAsync<Rent_Book>(query, new { cust_id = cust_id });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
