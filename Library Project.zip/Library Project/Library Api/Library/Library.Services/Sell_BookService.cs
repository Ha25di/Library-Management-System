﻿using Library.DataAccess;
using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    public class Sell_BookService : ISell_BookService
    {
        protected readonly ISell_BookRepository _SellBookRepository;

        public Sell_BookService(ISell_BookRepository _sellBookRepository)
        {
            _SellBookRepository = _sellBookRepository;
        }

        public Task AddSoldBook(Sell_Book soldBook)
        {
            return _SellBookRepository.AddSoldBook(soldBook);
        }

        public Task<IEnumerable<Sell_Book>> getAllSoldBooks()
        {
            return _SellBookRepository.getAllSoldBooksAsync();
        }

        public Task<IEnumerable<Sell_Book>> getSoldBookByCustId(int cust_id)
        {
           return _SellBookRepository.getSoldBookByCustIdAsync(cust_id);
        }
    }
}
