﻿using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    public interface IBookService
    {
        Task<IEnumerable<Book>> getAllBooks();

        Task<Book> GetBookById(int id);

        Task<Book> GetBookByTitle(string title);

        Task<IEnumerable<Book>> GetBookByGenre(string genre);

        Task AddBook(Book book);

        Task UpdateNumOfCopies(int id, int NumOfCopies);

        Task DeleteBook(int id);

        Task<int> GetNbAvailableById(int _id);

        Task DecreaseQty(int id);

        Task<decimal> GetRentPrice(int id);

        Task<decimal> GetSellPrice(int id);

        Task updateCopiesAfterRent();
    }
}
