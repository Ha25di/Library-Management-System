﻿using Library.DataAccess;
using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    public class Rent_BookService : IRent_BookService
    {
        protected readonly IRent_BookRepository _RentBookRepository;

        public Rent_BookService(IRent_BookRepository _rentBookRepository)
        {
            _RentBookRepository = _rentBookRepository;
        }

        public Task AddRentedBook(Rent_Book rentBook)
        {
            return _RentBookRepository.AddRentedBook(rentBook);
        }

        public Task<IEnumerable<Rent_Book>> getAllRentedBooks()
        {
            return _RentBookRepository.getAllRentedBooksAsync();
        }

        public Task<IEnumerable<Rent_Book>> getRentedBookByCustId(int cust_id)
        {
            return _RentBookRepository.getRentedBookByCustIdAsync(cust_id);
        }
    }
}
