﻿using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    public interface IRent_BookService
    {
        Task<IEnumerable<Rent_Book>> getAllRentedBooks();

        Task AddRentedBook(Rent_Book rentBook);

        Task<IEnumerable<Rent_Book>> getRentedBookByCustId(int cust_id);
    }
}
