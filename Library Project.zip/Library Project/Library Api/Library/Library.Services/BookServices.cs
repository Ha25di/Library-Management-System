﻿using Library.DataAccess;
using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    public class BookServices : IBookService
    {

        protected readonly IBookRepository _bookRepository;

        public BookServices (IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }

        public Task AddBook(Book book)
        {
            return _bookRepository.AddBook(book);
        }

        public Task DeleteBook(int id)
        {
            return _bookRepository.DeleteBook(id);
        }

        public Task<IEnumerable<Book>> getAllBooks()
        {
           return  _bookRepository.getAllBooksAsync();
        }

        public Task<Book> GetBookById(int id)
        {
            return _bookRepository.GetBookByIdAsync(id);
        }


        public Task UpdateNumOfCopies(int id, int NumOfCopies)
        {
            return _bookRepository.UpdateNumOfCopies(id, NumOfCopies);
        }

        public Task<Book> GetBookByTitle(string title)
        {
            return _bookRepository.GetBookByTitleAsync(title);
        }

        public  Task <IEnumerable<Book>> GetBookByGenre(string genre)
        {
            return _bookRepository.GetBookByGenreAsync(genre);
        }

        public Task<int> GetNbAvailableById(int Id)
        {
            return _bookRepository.GetNbAvailableByIdAsync(Id);
        }

        public Task DecreaseQty(int id)
        {
            return _bookRepository.DecreaseQty(id);
        }

        public Task<decimal> GetRentPrice(int id)
        {
            return _bookRepository.GetRentPriceAsync(id);
        }

        public Task<decimal> GetSellPrice(int id)
        {
            return _bookRepository.GetSellPriceAsync(id);
        }

        public Task updateCopiesAfterRent()
        {
            return _bookRepository.updateCopiesAfterRent();
        }
    }
}
