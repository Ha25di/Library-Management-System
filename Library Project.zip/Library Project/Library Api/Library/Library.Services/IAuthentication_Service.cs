﻿using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    public interface IAuthentication_Service
    {
        Task<IEnumerable<Authentication_System>> getAllUsernames();

        Task AddUsername(Authentication_System authentication_System);

        Task<bool> CheckUser(string username, string password);
    }
}
