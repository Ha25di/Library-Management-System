﻿using Library.DataAccess;
using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    public class CustomerService : ICustomerService
    {
        protected readonly ICustomerRepository _customerRepository;

        public CustomerService (ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        public Task AddCustomer(Customer customer)
        {
            return _customerRepository.AddCustomer(customer);
        }

        public Task DeleteCustomer(int id)
        {
           return  _customerRepository.DeleteCustomer(id);
        }

        public Task<IEnumerable<Customer>> getAllCustomers()
        {
            return _customerRepository.getAllCustomersAsync();
        }

        public Task<Customer> GetCustomerById(int id)
        {
            return _customerRepository.GetCustomerByIdAsync(id);
        }
    }
}
