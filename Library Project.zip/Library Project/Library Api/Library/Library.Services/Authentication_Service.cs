﻿using Library.DataAccess;
using Library.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    public class Authentication_Service : IAuthentication_Service
    {

        protected readonly IAuthentication_Repository _authenticationRepository;

        public Authentication_Service(IAuthentication_Repository authenticationRepository)
        {
            _authenticationRepository = authenticationRepository;
        }

        public Task AddUsername(Authentication_System authentication_System)
        {
            return _authenticationRepository.AddUsername(authentication_System);
        }

        public Task<bool> CheckUser(string username, string password)
        {
            return _authenticationRepository.CheckUserAsync(username, password);    
        }

        public Task<IEnumerable<Authentication_System>> getAllUsernames()
        {
            return _authenticationRepository.getAllUsernamesAsync();   
        }
    }
}
