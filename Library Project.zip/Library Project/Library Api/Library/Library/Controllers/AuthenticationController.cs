﻿using Library.Domain;
using Library.Services;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{

    [ApiController]
    [Route("Api/[controller]")]
    public class AuthenticationController : ControllerBase
    {
        protected readonly IAuthentication_Service _authenticationService;

        public AuthenticationController(IAuthentication_Service authenticationService)
        {
            _authenticationService = authenticationService;
        }


        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getAllUsernames()
        {
            var usernames = await _authenticationService.getAllUsernames();
            return Ok(usernames);
        }


        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> AddUsername([FromBody] Authentication_System authentication_System)
        {
            if (ModelState.IsValid)
            {
                await _authenticationService.AddUsername(authentication_System);
                return CreatedAtAction(nameof(AddUsername), new { username = authentication_System.Username }, authentication_System);
            }
            else
            {
                return BadRequest();
            }
        }

       

        [HttpPost("checkUser")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> CheckUser([FromBody] Authentication_System  credentials)
        {
            if (credentials == null || string.IsNullOrEmpty(credentials.Username) || string.IsNullOrEmpty(credentials.Password))
            {
                return BadRequest("Username and password are required.");
            }

            var isValidUser = await _authenticationService.CheckUser(credentials.Username, credentials.Password);

            if (isValidUser)
            {
                return Ok("User is valid.");
            }
            else
            {
                return BadRequest("Invalid username or password.");
            }
        }












    }
}
