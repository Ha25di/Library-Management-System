﻿using Library.DataAccess;
using Library.Domain;
using Library.Services;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [ApiController]
    [Route("Api/[controller]")]
    public class BookController : ControllerBase
    {
        protected readonly IBookService _BookService;

        public BookController(IBookService BookService)
        {
            _BookService = BookService;
        }



        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getAllBooks()
        {
            var books = await _BookService.getAllBooks();
            return Ok(books);
        }


        [HttpGet("id/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getBookById(int id)
        {
            var book = await _BookService.GetBookById(id);
            return Ok(book);
        }

        [HttpGet("title/{title}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getBookByTitle(string title)
        {
            var book = await _BookService.GetBookByTitle(title);
            return Ok(book);
        }


        [HttpGet("genre/{genre}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getBookByGenre(string genre)
        {
            var book = await _BookService.GetBookByGenre(genre);
            return Ok(book);
        }


        [HttpGet("NbAvailable/{Id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetNbAvailableById(int Id)
        {
            var nb = await _BookService.GetNbAvailableById(Id);
            return Ok(nb);
        }



        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> AddBook([FromBody] Book book)
        {
            if (ModelState.IsValid)
            {
                await _BookService.AddBook(book);
            }

            else
            {
                return BadRequest();
            }

            return CreatedAtAction(nameof(AddBook), new { Book_id = book.Book_id }, book);
        }



        [HttpPut("{id}/{NumOfCopies}")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> UpdateNumOfCopies(int id, int NumOfCopies)
        {
            if (ModelState.IsValid)
            {
               await _BookService.UpdateNumOfCopies(id, NumOfCopies);    
            }

            else
            {
                return BadRequest();
            }
            return Ok();
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> DeleteBook(int id)
        {
            await _BookService.DeleteBook(id);
            return Ok();
        }

        [HttpPut("decreaseQty/{id}")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> DecreaseQty(int id)
        {
            if (ModelState.IsValid)
            {
                await _BookService.DecreaseQty(id);
            }

            else
            {
                return BadRequest();
            }
            return Ok();
        }

        [HttpGet("Rent_Price/{Id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetRentPriceById(int Id)
        {
            decimal rPrice = await _BookService.GetRentPrice(Id);
            return Ok(rPrice);
        }

        [HttpGet("Sell_Price/{Id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSellPriceById(int Id)
        {
            decimal rPrice = await _BookService.GetSellPrice(Id);
            return Ok(rPrice);
        }

        [HttpPut("increaseAfterRent")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> IncreaseQty()
        {
            if (ModelState.IsValid)
            {
                await _BookService.updateCopiesAfterRent();
            }

            else
            {
                return BadRequest();
            }
            return Ok();
        }











    }
}
