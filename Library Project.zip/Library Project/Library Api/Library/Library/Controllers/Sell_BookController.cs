﻿using Library.Domain;
using Library.Services;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [ApiController]
    [Route("Api/[controller]")]
    public class Sell_BookController : ControllerBase
    {
        protected readonly ISell_BookService _Sell_BookService;

        public Sell_BookController(ISell_BookService BookService)
        {
            _Sell_BookService = BookService;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getAllSoldBooks()
        {
            var soldBooks = await _Sell_BookService.getAllSoldBooks();
            return Ok(soldBooks);
        }

        [HttpGet("{cust_id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getSoldBookByCustId(int cust_id)
        {
            var soldBooks = await _Sell_BookService.getSoldBookByCustId(cust_id);
            return Ok(soldBooks);
        }


        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> AddSoldBook([FromBody] Sell_Book sellBook)
        {
            if (ModelState.IsValid)
            {
                await _Sell_BookService.AddSoldBook(sellBook);
                return CreatedAtAction(nameof(AddSoldBook), new { Sale_Book_id = sellBook.Sale_Book_id }, sellBook);
            }

            else
            {
                return BadRequest();
            }

            
        }


    }
}
