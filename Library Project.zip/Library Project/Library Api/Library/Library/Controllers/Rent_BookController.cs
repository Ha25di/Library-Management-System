﻿using Microsoft.AspNetCore.Mvc;
using Library.DataAccess;
using Library.Domain;
using Library.Services;


namespace Library.Controllers
{
    [ApiController]
    [Route("Api/[controller]")]
    public class Rent_BookController : ControllerBase
    {

            protected readonly IRent_BookService _Rent_BookService;

            public Rent_BookController(IRent_BookService BookService)
            {
                _Rent_BookService = BookService;
            }



            
            [HttpGet]
            [ProducesResponseType(StatusCodes.Status200OK)]
            public async Task<IActionResult> getAllRentedBooks()
            {
                var rentBooks = await _Rent_BookService.getAllRentedBooks();
                return Ok(rentBooks);
            }


        [HttpGet ("{cust_id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getRentedBookByCustId(int cust_id)
        {
            var rentBooks = await _Rent_BookService.getRentedBookByCustId(cust_id);
            return Ok(rentBooks);
        }


        [HttpPost]
              [ProducesResponseType(StatusCodes.Status201Created)]
              [ProducesResponseType(StatusCodes.Status200OK)]

              public async Task<IActionResult> AddRentedBook([FromBody] Rent_Book rentBook)
              {
                  if (ModelState.IsValid)
                  {
                      await _Rent_BookService.AddRentedBook(rentBook);
                      return CreatedAtAction(nameof(AddRentedBook), new { Rent_Book_Id = rentBook.Rent_Book_Id }, rentBook);
                  }

                  else
                  {
                      return BadRequest();
                  }

                 
              }

              

        }
}
