﻿using Library.Domain;
using Library.Services;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [ApiController]
    [Route("Api/[controller]")]
    public class CustomerController : ControllerBase
    {
        protected readonly ICustomerService _CustomerService;

        public CustomerController(ICustomerService CustomerService)
        {
            _CustomerService = CustomerService;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getAllCustomers()
        {
            var customers = await _CustomerService.getAllCustomers();
            return Ok(customers);
        }


        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> getCustomerById(int id)
        {
            var customer = await _CustomerService.GetCustomerById(id);
            return Ok(customer);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> AddCustomer([FromBody] Customer customer)
        {
            if (ModelState.IsValid)
            {
                await _CustomerService.AddCustomer(customer);
            }

            else
            {
                return BadRequest();
            }

            return CreatedAtAction(nameof(AddCustomer), new { Customer_id = customer.Customer_id}, customer);
        }


        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> DeleteCustomer(int id)
        {
            await _CustomerService.DeleteCustomer(id);
            return Ok();
        }










    }
}
